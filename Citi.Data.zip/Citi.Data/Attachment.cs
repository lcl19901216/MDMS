﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Citi.Data
{
    public class Attachment
    {
        private string Result;
        public string Upload(HttpPostedFile files, Dictionary<string, string> Dic)
        {
            string uploadpath = "../xml/upload/" + Dic["pagetype"] + "/";
            string path = HttpContext.Current.Server.MapPath(uploadpath);
            string attachname = files.FileName;
            path = path + Dic["filename"] + "{$}" + Dic["attachtype"] + "{$}" + Dic["rowid"] + "{$}" + DateTime.Now.ToString("yyyyMMdd HH_mm_ss") + "{$}" + attachname;
            try
            {
                files.SaveAs(path);
                Result = "ok";
            }
            catch (Exception ex)
            {
                Result = ex.Message;
            }
            return Result;
        }

        public string DelUpLoadFile(Dictionary<string, string> Dic)
        {
            string pagetype = Dic["pagetype"];
            string originname = Dic["originname"];
            string path = HttpContext.Current.Server.MapPath("../xml/upload/" + pagetype);
            path += "\\" + originname;
            if (File.Exists(path))
            {
                File.Delete(path);
                Result = "ok";
            }
            return Result;
        }

        public string UploadView(Dictionary<string, string> Dic)
        {
            Result = "[";

            string filename = Dic["filename"];
            string pagetype = Dic["pagetype"];
            string rowid = Dic["rowid"];
            string attachtype = Dic["attachtype"];
            string path = HttpContext.Current.Server.MapPath("../xml/upload/" + pagetype);
            DirectoryInfo direcinfo = new DirectoryInfo(path);

            foreach (FileInfo fileinfo in direcinfo.GetFiles())
            {
                string attachname = fileinfo.Name;
                List<string> attachdetail = attachname.Split(new string[] { "{$}" }, StringSplitOptions.None).ToList();
                if (attachdetail[0] == filename && attachdetail[1] == attachtype && attachdetail[2] == rowid)
                {
                    string attachJson = "{";
                    string suffix = Path.GetExtension(fileinfo.FullName);
                    string imgpath = getFileTypeImg(suffix);
                    if (imgpath == "img")
                    {
                        imgpath = "../xml/upload/" + pagetype + "/" + attachname;
                    }
                    string imgname = attachdetail[4];
                    string imgdate = attachdetail[3];

                    attachJson += "\"imgnameshort\":\"" + imgname + "\",\"imgname\":\"" + imgname + "_" + imgdate + "\",\"imgpath\":\"" + imgpath + "\",\"originname\":\"" + attachname + "\","
                               + "\"filename\":\"" + filename + "\",\"pagetype\":\"" + pagetype + "\",\"rowid\":\"" + rowid + "\",\"attachtype\":\"" + attachtype + "\"";
                    attachJson += "},";
                    Result += attachJson;
                }
            }

            Result = Result.TrimEnd(',');
            Result += "]";
            return Result;
        }

        private string getFileTypeImg(string suffix)
        {
            string imgpath = "";
            switch (suffix.ToLower())
            {
                case ".pdf":
                    imgpath = "../Scripts/zyupload/skins/images/fileType/pdf.png";
                    break;
                case ".xls":
                case ".xlsx":
                    imgpath = "../Scripts/zyupload/skins/images/fileType/xls.png";
                    break;
                case ".doc":
                case ".docx":
                    imgpath = "../Scripts/zyupload/skins/images/fileType/doc.png";
                    break;
                case ".txt":
                    imgpath = "../Scripts/zyupload/skins/images/fileType/txt.png";
                    break;
                case ".ppt":
                    imgpath = "../Scripts/zyupload/skins/images/fileType/ppt.png";
                    break;
                case ".zip":
                    imgpath = "../Scripts/zyupload/skins/images/fileType/zip.png";
                    break;
                case ".rar":
                    imgpath = "../Scripts/zyupload/skins/images/fileType/rar.png";
                    break;
                case ".jpg":
                case ".png":
                case ".jpeg":
                case ".gif":
                    imgpath = "img";
                    break;
            }
            return imgpath;
        }
    }
}
