﻿using Citi.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Linq;
using System.Xml;
using System.Text.RegularExpressions;

namespace Citi.Data
{
    public class HandleData
    {
        string Result = string.Empty;
        List<string> SearchResult = new List<string>();
        Dictionary<int, SearchContent> Dic = new Dictionary<int, SearchContent>();
        int gradual = 1;

        //列表页数据读取
        public string LoadListData(string pagetype)
        {
            string oppPath = IOHandle.oppPath(pagetype, ModelPath.Data);

            string path = HttpContext.Current.Server.MapPath(oppPath);
            DirectoryInfo folder = new DirectoryInfo(path);
            DataTable ListData = new DataTable();

            foreach (FileInfo file in folder.GetFiles("*.xml"))
            {
                LoadListDataForDataTable(file, ListData, pagetype);
            }

            Result = JsonUtil.ToJson(ListData, ListData.Rows.Count);
            return Result;
        }

        //编辑页数据读取
        public string LoadEditData(string filename, string status, string pagetype)
        {
            string attachNumJson = string.Empty;
            string maxrowid = "0";
            string datasourceJson = string.Empty;
            DataTable EditData = new DataTable();

            EditData.Columns.Add("id", typeof(System.String));
            EditData.Columns.Add("name", typeof(System.String));
            EditData.Columns.Add("parentid", typeof(System.String));
            EditData.Columns.Add("value", typeof(System.String));
            EditData.Columns.Add("editor", typeof(System.String));
            EditData.Columns.Add("listfieldname", typeof(System.String));
            EditData.Columns.Add("datasource", typeof(System.String));

            DataTable EditLogData = new DataTable();

            EditLogData.Columns.Add("id", typeof(System.String));
            EditLogData.Columns.Add("time", typeof(System.String));
            EditLogData.Columns.Add("issue", typeof(System.String));
            EditLogData.Columns.Add("cause", typeof(System.String));
            EditLogData.Columns.Add("status", typeof(System.String));
            EditLogData.Columns.Add("resolve", typeof(System.String));
            EditLogData.Columns.Add("attachment", typeof(System.String));

            string oppPath = string.Empty;
            string path = string.Empty;
            DataSet ds = new DataSet();

            if (status.Equals("add"))
            {
                oppPath = IOHandle.oppPath(pagetype, ModelPath.Model);
                path = HttpContext.Current.Server.MapPath(oppPath);
            }
            else if (status.Equals("edit"))
            {
                oppPath = IOHandle.oppPath(pagetype, ModelPath.Data);
                path = HttpContext.Current.Server.MapPath(oppPath + filename);
            }

            FileInfo fileinfo = new FileInfo(path);
            LoadEditDataForDataTable(fileinfo, EditData); //data
            LoadEditLogDataForDataTable(fileinfo, EditLogData); //log
            attachNumJson = LoadAttachData(filename, pagetype); //attachment
            datasourceJson = getPageDatasource(fileinfo);  //datasource

            ds.Tables.Add(EditData);
            ds.Tables.Add(EditLogData);

            Result = "[";

            for (int i = 0; i < ds.Tables.Count; i++)
            {
                string EditJson = JsonUtil.ToJsArray(ds.Tables[i]);
                EditJson += ",";
                Result += EditJson;
            }

            Result += attachNumJson;
            if (EditLogData.Rows.Count > 0)
            {
                maxrowid = (string)EditLogData.Compute("Max(id)", null);
            }

            Result += ",{\"maxrowid\":\"" + maxrowid + "\"},";
            Result += datasourceJson;
            Result += "]";
            return Result;
        }


        //拼接第二页签内容
        public string LoadEditImgData(string filename, string pagetype, string status)
        {
            string oppPath = string.Empty;
            string path = string.Empty;

            if (status == "add")
            {
                oppPath = IOHandle.oppPath(pagetype, ModelPath.Model);
                path = HttpContext.Current.Server.MapPath(oppPath);
            }
            else if (status == "edit")
            {
                oppPath = IOHandle.oppPath(pagetype, ModelPath.Data);
                path = HttpContext.Current.Server.MapPath(oppPath + filename);
            }

            FileInfo fileinfo = new FileInfo(path);
            DataTable ImgData = EditAddFlowData(fileinfo, pagetype);
            Result = JsonUtil.ToJsArray(ImgData);

            return Result;
        }

        //保存编辑页数据
        public string SaveEditData(string filename, string pagetype, string status, string SaveResult)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<?xml version=\"1.0\" encoding=\"utf-8\" ?>");
            sb.Append("<root><rows>");
            string oppPath = string.Empty;
            XmlDocument target = new XmlDocument();

            if (status == "add")
            {
                oppPath = IOHandle.oppPath(pagetype, ModelPath.Model);
                target = IOHandle.ReadFileToXmlObject(oppPath);
            }
            else if (status == "edit")
            {
                oppPath = IOHandle.oppPath(pagetype, ModelPath.Data);
                target = IOHandle.ReadFileToXmlObject(oppPath + filename);
            }

            XmlDocument source = new XmlDocument();
            source.LoadXml(SaveResult);
            XmlNode targetDetail = target.SelectSingleNode("/root/detail");
            XmlNode targetRelation = target.SelectSingleNode("/root/detail/relation");

            XmlNode grid1data = source.SelectSingleNode("/root/grid1data");
            XmlNode grid2data = source.SelectSingleNode("/root/grid2data");
            XmlNode kindeditordata = source.SelectSingleNode("/root/kindeditordata");
            XmlNodeList graphicsdatas = source.SelectNodes("/root/graphicsdata/visio");
            sb.Append(grid1data.InnerXml).Append("</rows>");

            sb.Append("<detail>");

            foreach (XmlNode graphicsdata in graphicsdatas)
            {
                string visioname = graphicsdata.InnerXml;
                XmlNode currentvisio = null;

                if (targetDetail != null)
                {
                    currentvisio = targetDetail.SelectSingleNode("visio[@visioname='" + visioname + "']");
                }

                if (currentvisio == null)
                {
                    sb.Append("<visio visioname=\"" + visioname + "\"><location>").Append("</location></visio>");
                }
                else
                {
                    sb.Append(currentvisio.OuterXml);
                }
            }

            sb.Append("<solve>").Append(kindeditordata == null ? "" : kindeditordata.InnerText).Append("</solve>");
            sb.Append("<errorlog>").Append(grid2data == null ? "" : grid2data.InnerXml).Append("</errorlog>");
            sb.Append("<relation>").Append(targetRelation == null ? "" : targetRelation.InnerXml).Append("</relation>");
            sb.Append("</detail>");
            sb.Append("</root>");
            string dataResult = sb.ToString();

            XmlDocument SaveDoc = new XmlDocument();
            SaveDoc.LoadXml(dataResult);

            try
            {
                oppPath = IOHandle.oppPath(pagetype, ModelPath.Data);
                string Savepath = HttpContext.Current.Server.MapPath(oppPath + filename);
                SaveDoc.Save(Savepath);
                Result = "ok";
            }
            catch (Exception ex)
            {
                Result = ex.Message;
            }

            return Result;
        }

        private string getPageDatasource(FileInfo file)
        {
            string datasourceJson = "{";
            Dictionary<string, string> dic = new Dictionary<string, string>();
            XmlDocument xd = IOHandle.ReadFileToXmlObject(file);
            XmlNodeList datasourceList = xd.GetElementsByTagName("datasource");
            foreach (XmlNode datasource in datasourceList)
            {
                if (!dic.ContainsKey(datasource.InnerText))
                {
                    dic.Add(datasource.InnerText, datasource.InnerText);
                }
            }
            XmlDocument xddatasource = IOHandle.ReadFileToXmlObject("../xml/config/DataSource/datasource.xml");
            XmlNodeList datas = xddatasource.SelectNodes("/root/row");
            foreach (XmlNode data in datas)
            {
                string key = data.SelectSingleNode("key").InnerText;

                if (dic.ContainsKey(key))
                {
                    XmlNodeList datavalues = data.SelectNodes("datas/data");

                    string valuesJson = "[";
                    foreach (XmlNode datavalue in datavalues)
                    {
                        valuesJson += "{\"id\":\"" + datavalue.InnerText + "\",\"text\":\"" + datavalue.InnerText + "\"},";
                    }
                    valuesJson = valuesJson.TrimEnd(',');
                    valuesJson += "]";
                    datasourceJson += "\"" + key + "\":" + valuesJson + ",";
                }
            }

            datasourceJson = datasourceJson.TrimEnd(',');
            datasourceJson += "}";
            return datasourceJson;
        }

        //增加visio的字段
        private DataTable EditAddFlowData(FileInfo file, string pagetype)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("visio", typeof(System.String));
            dt.Columns.Add("solve", typeof(System.String));
            dt.Columns.Add("relation", typeof(System.String));
            DataRow dr = dt.NewRow();

            FileStream fs = file.Open(FileMode.Open, FileAccess.Read);
            XmlDocument xd = new XmlDocument();
            xd.Load(fs);
            fs.Dispose();
            string visiostr = "";
            string solveHtml = "";

            XmlNodeList nodes = xd.SelectNodes("/root/detail/visio");

            foreach (XmlNode node in nodes)
            {
                string visioname = node.Attributes["visioname"].InnerText;

                visiostr += "{\"visioname\":\"" + visioname + "\"},";
            }

            XmlNode solve = xd.SelectSingleNode("/root/detail/solve");

            if (solve != null)
            {
                solveHtml = solve.InnerXml;
            }

            XmlNodeList relationLists = xd.SelectNodes("/root/detail/relation/flow");
            string relationstr = "[";

            //拼接上下游json
            foreach (XmlNode relationList in relationLists)
            {
                string streams = "{";
                XmlNodeList upstreams = relationList.SelectNodes("upstream");
                XmlNodeList downstreams = relationList.SelectNodes("downstream");

                string upstreamsstr = "\"upstream\":[";
                string downstreamsstr = "\"downstream\":[";
                foreach (XmlNode upstream in upstreams)
                {
                    upstreamsstr += "{";
                    upstreamsstr += "\"filename\":\"" + upstream.Attributes["filename"].InnerText + "\",";
                    upstreamsstr += "\"pagetype\":\"" + upstream.Attributes["pagetype"].InnerText + "\",";
                    upstreamsstr += "\"status\":\"" + upstream.Attributes["status"].InnerText + "\"";
                    upstreamsstr += "},";
                }
                upstreamsstr = upstreamsstr.TrimEnd(',') + "]";
                foreach (XmlNode downstream in downstreams)
                {
                    downstreamsstr += "{";
                    downstreamsstr += "\"filename\":\"" + downstream.Attributes["filename"].InnerText + "\",";
                    downstreamsstr += "\"pagetype\":\"" + downstream.Attributes["pagetype"].InnerText + "\",";
                    downstreamsstr += "\"status\":\"" + downstream.Attributes["status"].InnerText + "\"";
                    downstreamsstr += "},";
                }
                downstreamsstr = downstreamsstr.TrimEnd(',') + "]";
                streams += upstreamsstr + "," + downstreamsstr + "},";

                relationstr += streams;
            }

            visiostr = "[" + visiostr.TrimEnd(',') + "]";
            relationstr = relationstr.TrimEnd(',') + "]";

            dr["solve"] = solveHtml;
            dr["visio"] = visiostr;
            dr["relation"] = relationstr;

            dt.Rows.Add(dr);
            return dt;
        }

        //列表页数据读取
        private void LoadListDataForDataTable(FileInfo file, DataTable dt, string pagetype)
        {
            DataRow dr = dt.NewRow();
            XmlDocument xd = IOHandle.ReadFileToXmlObject(file);

            XmlNodeList nodes = xd.SelectNodes("/root/rows/row");

            foreach (XmlNode node in nodes)
            {
                if (node["listfieldname"] != null)
                {
                    if (dt.Columns.Count != 0 && dt.Columns.Contains(node["listfieldname"].InnerText))
                    {
                        dr[node["listfieldname"].InnerText] = node["value"].InnerText;
                    }
                    else
                    {
                        DataColumn dc = new DataColumn(node["listfieldname"].InnerText, typeof(string));
                        dt.Columns.Add(dc);
                        dr[node["listfieldname"].InnerText] = node["value"].InnerText;
                    }
                }
            }

            dt.Rows.Add(dr);

        }

        //编辑页数据读取
        private void LoadEditDataForDataTable(FileInfo file, DataTable dt)
        {
            DataRow dr = dt.NewRow();
            XmlDocument xd = IOHandle.ReadFileToXmlObject(file);

            XmlNodeList nodes = xd.SelectNodes("/root/rows/row");

            foreach (XmlNode node in nodes)
            {
                dr["id"] = node["id"].InnerText;
                dr["parentid"] = node["parentid"].InnerText;
                dr["name"] = "<lg title=\"" + node["name"].InnerText + "\">" + node["name"].InnerText + "</lg>";
                dr["editor"] = node["editor"].InnerText;
                dr["value"] = node["value"].InnerText;
                dr["listfieldname"] = node["listfieldname"] != null ? node["listfieldname"].InnerText : "";
                dr["datasource"] = node["datasource"] != null ? node["datasource"].InnerText : "";
                dt.Rows.Add(dr);
                dr = dt.NewRow();
            }
        }

        //编辑页读取附件数量
        private string LoadAttachData(string filename, string pagetype)
        {
            string attachJson = "{";
            Dictionary<string, int> Dic = new Dictionary<string, int>();
            string oppPath = "../xml/upload/" + pagetype + "/";

            string path = HttpContext.Current.Server.MapPath(oppPath);
            DirectoryInfo direcinfo = new DirectoryInfo(path);

            foreach (FileInfo file in direcinfo.GetFiles())
            {
                if (file.Name.StartsWith(filename))
                {
                    List<string> attachdetail = file.Name.Split(new string[] { "{$}" }, StringSplitOptions.None).ToList();
                    string attachtype = attachdetail[1];
                    string rowid = attachdetail[2];
                    if (Dic.ContainsKey(attachtype + "_" + rowid))
                    {
                        Dic[attachtype + "_" + rowid] += 1;
                    }
                    else
                    {
                        Dic.Add(attachtype + "_" + rowid, 1);
                    }
                }
            }

            foreach (var item in Dic)
            {
                attachJson += "\"" + item.Key + "\":\"" + item.Value + "\",";
            }
            attachJson = attachJson.TrimEnd(',');
            attachJson += "}";
            return attachJson;
        }

        //编辑页历史记录读取
        private void LoadEditLogDataForDataTable(FileInfo file, DataTable dt)
        {
            DataRow dr = dt.NewRow();
            XmlDocument xd = IOHandle.ReadFileToXmlObject(file);

            XmlNodeList nodes = xd.SelectNodes("/root/detail/errorlog/log");
            foreach (XmlNode node in nodes)
            {
                dr["id"] = node["id"].InnerText;
                dr["time"] = node["time"].InnerText;
                dr["issue"] = node["issue"].InnerText;
                dr["cause"] = node["cause"].InnerText;
                dr["status"] = node["status"].InnerText;
                dr["resolve"] = node["resolve"].InnerText;
                dr["attachment"] = node["attachment"].InnerText;
                dt.Rows.Add(dr);
                dr = dt.NewRow();
            }
        }

        //搜索
        public void SearchMessage(string msg, string id)
        {

            DirectoryInfo theFolder = new DirectoryInfo(HttpContext.Current.Server.MapPath("../xml/data"));

            int filecounts = BelowDirectoryFilesCount(theFolder);

            string filecountsstr = "{\"filecount\":\"" + filecounts + "\" }";

            //抛出总数
            SignalR.SendMessage(filecountsstr, id);
            //开始检测关键字在每个文件中
            SearchKeyWordinFiles(theFolder, msg, id);
        }


        //开始检测关键字在每个文件中
        private void SearchKeyWordinFiles(DirectoryInfo path, string msg, string id)
        {
            MsgMapping(path, msg, id);

            foreach (DirectoryInfo subdir in path.GetDirectories())
            {
                SearchKeyWordinFiles(subdir, msg, id);
            }
        }

        //按照正则表达式来匹配msg
        private void MsgMapping(DirectoryInfo path, string msg, string id)
        {
            List<FileInfo> fileList = path.GetFiles().ToList();

            foreach (FileInfo file in fileList)
            {
                XmlDocument xd = IOHandle.ReadFileToXmlObject(file);
                string SearchResultJson = "[";
                List<string> fixparam = new List<string>() { "^" + msg + "$", path.Name, file.Name };

                //递归匹配
                GetTextFromXmlNode(xd.SelectSingleNode("/root"), 1, fixparam);

                foreach (string SearchResultDetail in SearchResult)
                {
                    SearchResultJson += SearchResultDetail + ",";
                }

                SearchResultJson = SearchResultJson.TrimEnd(',') + "]";
                SearchResultJson = SearchResultJson.Replace("\\", "\\\\");

                string str = "{\"gradual\":\"" + gradual + "\",\"SearchResult\":" + SearchResultJson
                    + ",\"id\":\"" + gradual + "\",\"pid\":\"" + fixparam[1] + "_" + fixparam[2] + "\",\"parentnode\":{\"id\":\""
                    + fixparam[1] + "_" + fixparam[2] + "\",\"pagetype\":\"" + fixparam[1] + "\",\"filename\":\"" + fixparam[2] + "\",\"text\":\"" + fixparam[2] + "\",\"pid\":0}}";

                SignalR.SendMessage(str, id);

                SearchResult = new List<string>();
                gradual++;
            }
        }

        //节点内容递归查询
        private void GetTextFromXmlNode(XmlNode node, int circle, List<string> fixparam)
        {
            //当前循环的层级数
            int currentLoopLayer = circle;
            int LayerLevel = 0;

            if (node.HasChildNodes && node.LocalName != "#text")
            {
                XmlNodeList ChildNodes = node.ChildNodes;

                for (int i = 0; i < ChildNodes.Count; i++)
                {
                    if (i == 0)
                    {
                        LayerLevel = circle;
                        currentLoopLayer++;
                    }

                    List<int> RemoveKeys = Dic.Select(x =>
                    {
                        if (x.Key >= LayerLevel)
                        {
                            return x.Key;
                        }
                        return 0;
                    }).Where(x => x != 0).ToList();

                    RemoveKeys.Select(x =>
                    {
                        Dic.Remove(x);
                        return x;
                    }).Count();

                    SearchContent Search = new SearchContent();
                    Search.LocalName = node.LocalName;
                    Search.Value = node.Value;
                    Dic.Add(LayerLevel, Search);

                    GetTextFromXmlNode(ChildNodes[i], currentLoopLayer, fixparam);
                }
            }
            else
            {
                if (ExcludeDetail(Dic) == true)
                {
                    string StepContent = node.InnerText;
                    Regex regex = new Regex(fixparam[0], RegexOptions.IgnoreCase);
                    bool isMatch = regex.IsMatch(StepContent);
                    if (isMatch && !string.IsNullOrEmpty(StepContent))
                    {
                        int DicTotal = Dic.Count;
                        string SearchResultStr = "";
                        for (int i = 1; i <= DicTotal; i++)
                        {
                            SearchResultStr += IOHandle.LocalNameReplace(Dic[i].LocalName) + "\\";
                        }

                        if (Dic.Count >= 4 && Dic[4].LocalName == "location")
                        {
                            StepContent = "流程图详细信息内容";

                        }
                        else if (Dic.Count >= 3 && Dic[3].LocalName == "solve")
                        {
                            StepContent = "错误查看步骤内容";
                        }

                        SearchResultStr = "{'msg':'" + SearchResultStr + StepContent + "'}";
                        SearchResult.Add(SearchResultStr);
                    }
                }
            }
        }

        //文件夹文件数量
        private int BelowDirectoryFilesCount(DirectoryInfo path)
        {
            int total = path.GetFiles().Count();

            foreach (DirectoryInfo subdir in path.GetDirectories())
            {
                total += BelowDirectoryFilesCount(subdir);
            }

            return total;
        }

        private bool ExcludeDetail(Dictionary<int, SearchContent> Dic)
        {
            bool FilterRusult = true;
            int Level = Dic.Count;
            if (Level >= 4)
            {
                if (Dic[2].LocalName == "rows" && Dic[3].LocalName == "row")
                {
                    if (Dic[4].LocalName != "value")
                    {
                        FilterRusult = false;
                    }
                }
            }
            return FilterRusult;
        }
    }



    //查询的内容
    internal class SearchContent
    {
        internal string LocalName { get; set; }
        internal string Value { get; set; }
    }
}
