﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Citi.Util;
using Microsoft.AspNet.SignalR;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_Send_Click(object sender, EventArgs e)
    {
        //SignalR.SendMessage(txt_msg.Text);
        ClientScript.RegisterStartupScript(this.GetType(), "message", "<script language='javascript' defer>alert('广播成功!');</script>");

    }
}
