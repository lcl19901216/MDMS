﻿var Public = new Object();


function addTab(tabname, url) {
    var tabs = mini.get("tabs1");

    //add tab
    var tab = { title: tabname, showCloseButton: "true", iconcls: "icon-cut" };
    tab = tabs.addTab(tab);

    //tab body
    var el = tabs.getTabBodyEl(tab);
    el.innerHTML = '<iframe src="' + url + '" style="width: 100%; height: 100%;"></iframe>';

    //active tab
    tabs.activeTab(tab);
}

/*获得cookie*/
function GetCookie(name, isobj/*指定返回是字符串还是对象*/) {
    var arg = name + "=";
    var alen = arg.length;
    var clen = document.cookie.length;
    var i = 0;
    var j = 0;
    while (i < clen) {
        j = i + alen;
        if (document.cookie.substring(i, j) == arg) {
            return getCookieVal(j, isobj);
        }
        i = document.cookie.indexOf(" ", i) + 1;
        if (i === 0) {
            break;
        }
    }
    return null;
};


/*通过偏移量获得cookie里面的值*/
function getCookieVal(offset, isobj/*指定是否返回字符串*/) {
    var strInfo = null;
    var endstr = document.cookie.indexOf(";", offset);

    if (endstr == -1) endstr = document.cookie.length;

    strInfo = unescape(document.cookie.substring(offset, endstr));

    var strArr = strInfo.split("&");
    var strData = "";
    if (strArr == undefined) return strInfo;
    for (var i = 0; i < strArr.length; i++) {
        var tmpInfo = strArr[i].substring(0, strArr[i].indexOf("="));
        var tmpInfo1 = strArr[i].substring(tmpInfo.length, strArr[i].length);

        strData += "\"" + tmpInfo + "\"" + ":\"" + tmpInfo1 + "\"";
        if (i != strArr.length - 1) {
            strData += ",";
        }
    }
    if (isobj)
        return strData.substring(strData.indexOf(":") + 2, strData.length - 1);
    return eval("({" + strData + "})");
}


//
//获取URL里的参数的值
//
Public.GetQueryString = function (name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
};




//
//得到一个随机数
//
Public.GetRandId = function () {
    var randID = Math.round(Math.random() * 10000);
    return randID;
};


//
//超连接到其它网页
//
Public.go = function (url) {
    if (url.indexOf("?") != -1)
        url += "&url=" + escape(window.location.href);
    else
        url += "?url=" + escape(window.location.href);

    window.location.href = url;
};


//
//超连接到其它网页
//
Public.goTab = function (tempUrl, tittle, tabid) {
    //parent.addTab(tabid, tittle, tempUrl);
    parent.addTab(tittle + '_' + tabid, tempUrl);
};


//
//回退
//
Public.back = function () {
    var url = window.location.href;
    if (window.location.href.indexOf("url") != -1)
        url = unescape(window.location.href.substring(window.location.href.indexOf("url") + 4));
    if (url != "")
        window.location.href = url;
};

//
//字符串转换日期
//
Public.parseDate = function (dateStr) {
    if (Public.GetType(dateStr) == "date") return dateStr;
    var arr = dateStr.split("-");
    return new Date(arr[0], arr[1] - 1, arr[2]);
}

//
//给URL增加随机码
//
Public.UrlRand = function (Url/*Url地址*/) {
    if (Url.toString().indexOf('?', 1) == -1)
        Url += "?myrand=" + Public.GetRandId();
    else
        Url += "&myrand=" + Public.GetRandId();

    return Url;
};



//
//用于对一个字符串进行插入或移出
//
Public.AddOrRemoveStr = function (IdList/*原始字符串*/, FindIdArr/*需要插入或移出的字符串*/, IsAdd/*是否是插入*/) {

    if (FindIdArr == undefined || FindIdArr == "")
        return IdList;



    var prolist;
    if (IdList != undefined && IdList != "" && IdList != null && IdList != "undefined") {
        //检查字符串两边是否有, 没有加上方便查找
        var str = IdList.toString();
        if (str.substring(str.length - 1, str.length) != ",")
            str += ",";
        if (str.substring(0, 1) != ",")
            str = "," + str;
        prolist = str;
    }
    else {
        prolist = ",";
    }


    var FindArr = FindIdArr.toString().split(",");
    for (var i = 0; i < FindArr.length; i++) {
        var find = "," + FindArr[i] + ",";
        if (!IsAdd) {
            if (prolist.indexOf(find) != -1) {
                var a = prolist.replace(find, ",");
                prolist = a;
            }
        } else {
            if (prolist.indexOf(find) == -1) {
                prolist += FindArr[i] + ",";  //往列表增加ID
            }

        }
        prolist = prolist.replace(",,", ",");
    }

    if (prolist != undefined && prolist != "" && prolist != null) {
        if (prolist.substring(0, 1) == ",") {
            prolist = prolist.substring(1, prolist.length); //remove first
        }

        if (prolist.substring(prolist.length - 1, prolist.length) == ",") {
            prolist = prolist.substring(0, prolist.length - 1); //remove last
        }
    }
    return prolist;
};





//
//Ajax请求方法,用于异步请求网页
//
Public.CallAjax = function (type/*请求方式POST,GET*/, url/*请求网址*/, data/*请求传递数据*/, successFN/*请求成功执行方法*/, errorFN/*请求失败执行方法*/, IsAsync) {

    var rand;
    if (url.indexOf('?', 1) == -1)
        rand = "?ajaxrand=" + Math.round(Math.random() * 10000);
    else
        rand = "&ajaxrand=" + Math.round(Math.random() * 10000);

    url += rand;
    $.ajax({
        type: type,
        url: url,
        async: IsAsync,
        data: data,
        success: successFN,
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            if (errorFN != null)
                errorFN(XMLHttpRequest);
        }
    });
};


///
///Ajax请求方法,用于异步请求网页2
///
Public.CallAjax2 = function (type/*请求方式POST,GET*/, url/*请求网址*/, data/*请求传递数据*/, successFN/*请求成功执行方法*/, errorFN/*请求失败执行方法*/, IsAsync) {
    var XmlHttpReq = function () {

        var zXml = {
            useActiveX: (typeof ActiveXObject != "undefined"),
            useDom: document.implementation && document.implementation.createDocument,
            useXmlHttp: (typeof XMLHttpRequest != "undefined")
        };

        zXml.ARR_XMLHTTP_VERS = ["MSXML2.XmlHttp.6.0", "MSXML2.XmlHttp.3.0"];

        zXml.ARR_DOM_VERS = ["MSXML2.DOMDocument.6.0", "MSXML2.DOMDocument.3.0"];

        if (zXml.useXmlHttp) {
            return new XMLHttpRequest();
        } else if (zXml.useActiveX) { //IE < 7.0 = use ActiveX

            if (!zXml.XMLHTTP_VER) {
                for (var i = 0; i < zXml.ARR_XMLHTTP_VERS.length; i++) {
                    try {
                        return new ActiveXObject(zXml.ARR_XMLHTTP_VERS[i]);
                        zXml.XMLHTTP_VER = zXml.ARR_XMLHTTP_VERS[i];
                        break;
                    } catch (oError) {
                    }
                }
            }

            if (zXml.XMLHTTP_VER) {
                return new ActiveXObject(zXml.XMLHTTP_VER);
            } else {
                throw new Error("Could not create XML HTTP Request.");
            }
        } else {
            throw new Error("Your browser doesn't support an XML HTTP Request.");
        }
    }

    var XmlRequest = XmlHttpReq();
    if (XmlRequest) {
        XmlRequest.onreadystatechange = function () {
            if (XmlRequest.readyState == 4 && XmlRequest.status == 200) {
                if (typeof successFN === 'function') {
                    successFN(XmlRequest.responseText);
                }
            }
            else if (XmlRequest.readyState == 4 && XmlRequest.status > 400) {
                if (typeof errorFN === 'function') {
                    errorFN(XmlRequest);
                }
            }
        }
        XmlRequest.open(type, url, IsAsync);
        XmlRequest.send(data);
    }
}



//Url参数序列化，将对象转换成url参数的形式
Public.SerializatUrlpara = function (obj) {
    var para = "";
    if (typeof obj == "object") {
        for (var o in obj) {
            if (typeof o != "function") {
                para += o + "=" + obj[o] + "&";
            }
        }
        return para == "" ? "" : para.substring(0, para.length - 1);
    }
    return para;
};




//
//小数位数限定，不足位自动补0
//
Public.FormatNumber = function (srcStr/*数值*/, nAfterDot/*小数位数*/) {

    var srcStr, nAfterDot;
    if (isNaN(parseFloat(srcStr)) || srcStr.length == 0 || srcStr == undefined || srcStr == null)
        srcStr = 0;
    srcStr = parseFloat(srcStr);


    var resultStr, nTen;
    srcStr = "" + srcStr + "";
    strLen = srcStr.length;
    dotPos = srcStr.indexOf(".", 0);

    if (dotPos == -1) {
        resultStr = srcStr + ".";
        for (var i = 0; i < nAfterDot; i++) {
            resultStr = resultStr + "0";
        }
    }
    else {
        if ((strLen - dotPos - 1) >= nAfterDot) {
            nAfter = dotPos + nAfterDot + 1;
            nTen = 1;
            for (var j = 0; j < nAfterDot; j++) {
                nTen = nTen * 10;
            }
            resultStr = Math.round(parseFloat(srcStr) * nTen) / nTen;
        }
        else {
            resultStr = srcStr;
            for (var i = 0; i < (nAfterDot - strLen + dotPos + 1) ; i++) {
                resultStr = resultStr + "0";
            }
        }
    }

    var temp = resultStr.toString();
    temp = temp.substring(temp.indexOf(".") + 1, temp.length);
    if (temp.length != parseFloat(nAfterDot)) {
        try {
            return Public.FormatNumber(resultStr, nAfterDot); //如果计算出的结果小数位不对就递归调用，直到小数准确为止
        } catch (e) {
            return resultStr;
        }

    }
    else
        return resultStr;
};



//
//用于字符串替换
//注：如果IsCycle 不传或传true 那将循环替换 例：aaaabbbb,将aa 替换为a 就回返回abbbb
//    如果IsCycle 为False那将顺序替换       例：aaaabbbb,将aa 替换为a 就回返回aabbbb
Public.ReplaceStr = function (oldStr/*原始字符串*/, repStr/*要替换的字符串*/, newStr/*替换新的字符串*/, IsCycle/*是否循环替换，默认为True*/) {

    if (!oldStr)
        return oldStr;

    var str = oldStr.toString();
    if (IsCycle == undefined || IsCycle == null)
        IsCycle = true;

    if (IsCycle) {
        //循环替换
        while (str.indexOf(repStr) != -1) {
            str = str.replace(repStr, newStr);
        }
    }
    else {
        //顺序替换
        //str = str.replace(repStr, newStr);//普通替换只能替换首次出现位置的字符 
        str = str.replace(new RegExp(repStr, "g"), newStr); //用正则替换会重复替换
    }
    return str;
};



//
//对日期类型变量进行格式化，例美国日期转为2012-03-04式日期
//
Public.DateFormat = function (_Date/*日期*/, format/*格式字符串 例:yyyy-MM-dd hh:mm:ss*/) {

    if (typeof (_Date) == "string") {
        return _Date;
    }

    var o = {
        "M+": _Date.getMonth() + 1,
        "d+": _Date.getDate(),
        "h+": _Date.getHours(),
        "m+": _Date.getMinutes(),
        "s+": _Date.getSeconds(),
        "q+": Math.floor((_Date.getMonth() + 3) / 3),
        "S": _Date.getMilliseconds()
    }
    if (/(y+)/.test(format)) {
        format = format.replace(RegExp.$1, (_Date.getFullYear() + "").substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
        }
    }
    return format;
}

//
//字符串格式化
//
Public.Format = function (src) {
    if (arguments.length == 0) return null;
    var args = Array.prototype.slice.call(arguments, 1);
    return src.replace(/\{(\d+)\}/g, function (m, i) {
        return args[i];
    });
}

//
//将特殊字符转换为XML可识别的转入字符 例： ± 转为&#177;
//
Public.SpecialStrToXML = function (xmlStr) {
    if (!xmlStr) {
        return xmlStr;
    }
    xmlStr = Public.ReplaceStr(xmlStr, "±", "&#177;", true);
    xmlStr = Public.ReplaceStr(xmlStr, "\"", "&#34;", true);
    xmlStr = Public.ReplaceStr(xmlStr, "<", "&#60;", true);
    xmlStr = Public.ReplaceStr(xmlStr, ">", "&#62;", true);
    //xmlStr = Public.ReplaceStr(xmlStr, "'", "&#8217;", true);

    return xmlStr;
};


//
//转换JSON字符串为JSON对象
//
Public.Eval = function (jsonStr) {
    if (jsonStr)
        return eval("(" + jsonStr + ")");
    else
        return null;
};



//
//移出空格
//
Public.trim = function (str) {
    while (str.indexOf(" ") != -1) {
        str = str.replace(" ", "");
    }
    return str;
};


//
//删除左边的空格
//
Public.ltrim = function (str) {
    if (str == undefined || str == null || str.length == 0)
        return str;
    else
        return str.replace(/(^\s*)/g, "");
};


//
//删除右边的空格
//
Public.rtrim = function (str) {
    if (str == undefined || str == null || str.length == 0)
        return str;
    else
        return str.replace(/(\s*$)/g, "");
};

//
// 移出字符串最后一位指定字符
//
Public.TrimEnd = function (str, keyword) {
    keyword = Public.rtrim(keyword);

    if (str == undefined || str == null || str.length == 0)
        return "";

    if (str.substring(str.length - keyword.length) == keyword)
        str = str.substring(0, str.length - keyword.length);
    return str;
};

//
// 移出字符串第一位指定字符
//
Public.TrimBegin = function (str, keyword) {
    if (str == undefined || str == null || str.length == 0)
        return "";

    if (str.substring(0, 1) == keyword)
        str = str.substring(1);
    return str;
};

/*清除cookie*/
function ClearCookie(name, path) {
    if (GetCookie(name)) {
        path = path || '/';
        document.cookie = name + '=' + '; expires=Thu, 01-Jan-70 00:00:01 GMT; path=' + path;
    }
}
//
//非空过虑
//
Public.IsEmpty = function (value/*要过虑的值*/, emptyValue/*如果为NULL或为undfined用此字代替*/) {
    var tmpResult = "";

    if (!emptyValue)
        emptyValue = '0';

    if (value) {
        value = value.toString();
    }

    if (emptyValue) {
        emptyValue = emptyValue.toString();
    }


    if (value && value != null && value != undefined && value.toString().length > 0 && value.toString() != "NaN" && value != "undefined" && value.toLowerCase() != "null") {
        tmpResult = value;
    }
    else {
        tmpResult = emptyValue;
    }
    return tmpResult;
};

//
//非空过虑
//
Public.IsNumber = function (value/*要过虑的值*/, emptyValue/*如果为NULL或为undfined用此字代替*/) {

    if (!emptyValue)
        emptyValue = 0;

    var tmpResult = "";
    if (isNaN(value) || !value) {
        tmpResult = emptyValue;
    } else {
        tmpResult = value;
    }
    return tmpResult;
};


//
//用于JS查询SQL数据，并以JSON信息返回
//
Public.QuerySql = function (SqlStr/*例：Select * from sys_user */, IsAsync/*是否异步,如果不传默认不是异步*/) {

    if (!SqlStr) {
        return;
    }
    if (IsAsync == undefined || IsAsync == null)
        IsAsync = false;
    SqlStr = encodeURIComponent(SqlStr);
    var jsonItem;
    var ReqUrl = "../Ashx/AjaxHandler.ashx?ac=ajaxSql&sql=" + SqlStr;
    Public.CallAjax("GET", ReqUrl, null, function (msg) {
        jsonItem = Public.Eval(msg);
    }, null, IsAsync);
    return jsonItem;
};


//
//用于字段值改变后自动带出该档案的相关联的值  例：选存货要带出 编码、名称、规则、单位等
//例：子表账值：Public.UpdateOneRow（"eb_product","{productmode:result.productmode,productunit:result.productunit}","pcode='${row.pcode}$' and pid=2",grid,row,col"） 
//grid表示当前触发事件的grid 
//row 表示当前触发事件的行 取值用：row.deptid
//col 表示当前触发事件的列
Public.UpdateOneRow = function (TabName, UpdateCol, Where, grid, row, col) {

    if (!UpdateCol) {
        alert('Public.UpdateOneRow方法 请指定UpdateCol参数'); return;
    }
    if (!Where) {
        alert('Public.UpdateOneRow方法  请指定Where参数'); return;
    }

    UpdateCol = UpdateCol.toLowerCase();
    UpdateCol = Public.ReplaceStr(UpdateCol, 'col_', 'Col_', true);


    if (Where.indexOf('{') != -1) {
        //宏表达式替换 
        try {
            Where = EditEventHelper.MacroExpression(Where, row);
        }
        catch (e) {
            alert(Where + '解析失败，请检查格式');
        }

    }

    var _para = {
        ac: 'ajaxQueryAndUpdate',
        tbname: escape(TabName),
        q: escape(Where),
        u: LoginUser.GetUserID(),
        rand: new Date().getTime()
    }
    Public.CallAjax("GET", "../ashx/AjaxHandler.ashx?" + Public.SerializatUrlpara(_para), null, function (msg) {

        var jsonItem = Public.Eval(msg);
        if (jsonItem && jsonItem.items && jsonItem.items.length > 0) {
            var result = jsonItem.items[0];
            var upr;
            try {
                upr = eval('(' + UpdateCol + ')');
            }
            catch (e) {
                alert(UpdateCol + ' 解析失败 请检查是否不符合JSON语法');
            }

            try {
                grid.updateRow(row, upr);
            } catch (e) {

            }

        }

    }, function (resp) {
        MsgHelper.Talert(resp.responseText);
    }, false);

}


//
//用于字段值改变后自动带出该档案的相关联的值  例：选择供应商要带出 税号、付款条件、银行账号等信息
//例：主表账值：Public.UpdateMainCol（"sys_user","{memo:result.BankName,rate:result.cemail}","iuserid='${Col_uid.MiniControl.getValue()}$'",col"）
//col 表示当前触发事件的字段控件对象
Public.UpdateMainCol = function (TabName, UpdateCol, Where, col) {



    if (!UpdateCol) {
        alert('Public.UpdateOneRow方法 请指定UpdateCol参数'); return;
    }
    if (!Where) {
        alert('Public.UpdateOneRow方法  请指定Where参数'); return;
    }

    UpdateCol = UpdateCol.toLowerCase();

    UpdateCol = Public.ReplaceStr(UpdateCol, 'col_', 'Col_', true);


    if (Where.indexOf('{') != -1) {
        //宏表达式替换
        try {
            Where = EditEventHelper.MacroExpression(Where, col);
        }
        catch (e) {
            alert(Where + '解析失败，请检查格式');
        }
    }

    var _para = {
        ac: 'ajaxQueryAndUpdate',
        tbname: escape(TabName),
        q: escape(Where),
        u: LoginUser.GetUserID(),
        rand: new Date().getTime()
    }
    Public.CallAjax("GET", "../ashx/AjaxHandler.ashx?" + Public.SerializatUrlpara(_para), null, function (msg) {

        var jsonItem = Public.Eval(msg);
        if (jsonItem && jsonItem.items && jsonItem.items.length > 0) {
            var result = jsonItem.items[0];
            var upr;
            try {
                upr = eval('(' + UpdateCol + ')');
            }
            catch (e) {
                alert(UpdateCol + ' 解析失败 请检查是否不符合JSON语法');
            }

            var miniCtr;
            for (var k in upr) {
                if (upr.hasOwnProperty(k)) {

                    if (k.indexOf('_show') != -1) {

                        var c = Public.ReplaceStr(k, '_show', '');
                        miniCtr = SaveMainColJson["Col_" + c].MiniControl;

                        if (!miniCtr) {
                            alert('Public.UpdateMainCol执行失败：不存在名为：' + c + '的 主表控件！');
                        }

                        if (typeof miniCtr.setText == "function") {
                            if (upr[k]) {
                                miniCtr.setText(upr[k]);
                            }
                        }

                    } else {

                        miniCtr = SaveMainColJson["Col_" + k].MiniControl;

                        if (!miniCtr) {
                            alert('Public.UpdateMainCol执行失败：不存在名为：' + k + '的 主表控件！');
                        }
                        miniCtr.setValue(upr[k]);

                    }

                }
            }

        }

    }, function (resp) {
        MsgHelper.Talert(resp.responseText);
    }, false);

}


//
//用于执行后台SQL代码
//
Public.ExecSql = function (FnCode/*SQL功能代码 例：Before_Edit_Click*/, ParFn/*请求参数生成方法*/, ResultFn/*执行完成回调方法*/, IsAsync/*是否异步*/) {

    if (IsAsync == undefined || IsAsync == null)
        IsAsync = false;

    var par = {};

    if (ParFn) {
        ParFn(par); //执行参数初始化
    }



    //请求后台
    var ReqUrl = "../Ashx/AjaxHandler.ashx?ac=ajaxEventSql&FnCode=" + FnCode + "&u=" + LoginUser.GetUserID() + "&pid=" + ProgramID;

    Public.CallAjax("POST", ReqUrl, par, function (msg) {

        var re = { type: '', msg: {} };
        try {
            var re2 = Public.Eval(msg);
            re.type = 'ok';
            re.msg = re2;

            if (ResultFn) {
                ResultFn(re);
            }

        } catch (e) {

            if (ResultFn) {
                re.type = 'error';
                re.msg = msg;
                ResultFn(re);
            }
        }

    }, null, IsAsync);



};


//
//用于执行后台SQL代码
//
Public.ExecProc = function (procName/*存储过程名*/, parStr/*存储过程参数*/, ResultFn/*执行完成回调方法*/, IsAsync/*是否异步*/) {

    if (IsAsync == undefined || IsAsync == null)
        IsAsync = false;


    //请求后台
    var ReqUrl = "../Ashx/AjaxHandler.ashx?ac=AjaxExecProc&pname=" + escape(procName) + "&u=" + LoginUser.GetUserID();

    var d = { procpar: escape(parStr) };

    Public.CallAjax("POST", ReqUrl, d, function (msg) {

        var re = { type: '', msg: {} };
        try {
            if (msg.toLowerCase() == 'ok') {
                re.type = 'ok';
                re.msg = 'ok';
            } else {
                var re2 = Public.Eval(msg);
                re.type = 'ok';
                re.msg = re2;
            }
            if (ResultFn) {
                ResultFn(re);
            }

        } catch (e) {

            if (ResultFn) {
                re.type = 'error';
                re.msg = msg;
                ResultFn(re);
            }
        }

    }, null, IsAsync);

};

//
//取出两字符串重复的部分
//
Public.GetRepeatStr = function (IdList1, IdList2, splitStr/*分隔符号，默认为豆号*/) {
    if (!IdList1 || !IdList2)
        return "";

    if (!splitStr)
        splitStr = ",";

    var TempArr1 = IdList1.toString().split(splitStr);
    var TempArr2 = IdList2.toString().split(splitStr);

    var result = "";
    for (var i = 0; i < TempArr1.length; i++) {
        for (var b = 0; b < TempArr2.length; b++) {
            if (TempArr1[i] == TempArr2[b])
                result += TempArr1[i] + splitStr;
        }
    }

    return this.TrimEnd(result, splitStr);
};


//
//将“数字列表”字符串转换为“字符串”列表字符串
//
Public.IntConvertToString = function (IdList/*原始字符串*/, SplitChar/*分隔符*/, AddChar/*字符串要增加的符号 例单引号*/) {

    if (IdList == undefined || IdList == "" || IdList == null)
        return "";

    var arr = IdList.split(SplitChar);
    for (var a = 0; a < arr.length; a++) {
        var temp = arr[a];
        arr[a] = AddChar + temp + AddChar;
    }
    return Public.ArrayToString(arr);
};




//
//SQL 注入检查 特殊字符将转为ASCII码
//

Public.UC_SqlFormatASCII = function (str) {


    if (str == null || str == undefined || str.length == 0) {
        return str;
    }
    else {

        str = str.toString();
        str = Public.ReplaceStr(str, "'", "ASCII(39)", true);
        str = Public.ReplaceStr(str, "\\", "ASCII(92)");
        str = Public.ReplaceStr(str, "[", "ASCII(91)");
        str = Public.ReplaceStr(str, "]", "ASCII(93)");
        str = Public.ReplaceStr(str, ">", "ASCII(62)");
        str = Public.ReplaceStr(str, "<", "ASCII(60)");
        str = Public.ReplaceStr(str, "+", "ASCII(43)");
        return str;
    }

}


//
//SQL 注入检查
//
Public.UC_SqlFormat = function (str, DoubleAppendQty/*双倍增加单引号数量、例'4 会被替换成'''' 默认为4*/) {

    if (str == null || str == undefined || str.length == 0)
    { return str; }
    else {
        /*
        if (DoubleAppendQty == undefined || DoubleAppendQty == null) {
        DoubleAppendQty = 4;
        }

        str = str.toString();
        if (DoubleAppendQty == 4) {
        str = str.ReplaceStr("'", "ASCII(39)ASCII(39)ASCII(39)ASCII(39)", true); // 将' 替换成 ''''
        }
        else if (DoubleAppendQty == 2) {
        str = str.ReplaceStr("'", "ASCII(39)ASCII(39)", true); // 将' 替换成 ''
        }
        else {
        str = str.ReplaceStr("'", "ASCII(39)", true); //默认为1
        }

        str = str.ReplaceStr("\\", "ASCII(92)");
        str = str.ReplaceStr("[", "ASCII(91)");
        str = str.ReplaceStr("]", "ASCII(93)");
        str = str.ReplaceStr(">", "ASCII(62)");
        str = str.ReplaceStr("<", "ASCII(60)");
        str = str.ReplaceStr("+", "ASCII(43)");
        */
        str = Public.ReplaceStr(str, "'", "", true);
        str = Public.ReplaceStr(str, "%", "", true);
        str = Public.ReplaceStr(str, ">", "", true);
        str = Public.ReplaceStr(str, "<", "", true);
        str = Public.ReplaceStr(str, "select", '', true);
        str = Public.ReplaceStr(str, "delete", '', true);
        str = Public.ReplaceStr(str, "where", '', true);
        str = Public.ReplaceStr(str, "from", '', true);
        str = Public.ReplaceStr(str, "update", '', true);
        str = Public.ReplaceStr(str, "backup", '', true);
        str = Public.ReplaceStr(str, "restore", '', true);
        str = Public.ReplaceStr(str, "drop", '', true);
        str = Public.ReplaceStr(str, "alter", '', true);
        str = Public.ReplaceStr(str, "\"", '', true);
        str = Public.ReplaceStr(str, "”", '', true);
        str = Public.ReplaceStr(str, "”", '', true);
        str = Public.ReplaceStr(str, "”", '', true);
        str = Public.ReplaceStr(str, "”", '', true);

    }
    return str;
};


//
//字符转ASCII码 
//
Public.CharToAscii = function (str) {
    if (!str)
        return "";
    else
        return str.charCodeAt();
}


//
//ASCII码转字符 
//
Public.AsciiToChar = function (tempStr) {
    if (!tempStr)
        return "";

    while (tempStr.indexOf("ASCII(") != -1) {
        var temp = tempStr.substring(tempStr.indexOf("ASCII(") + 6, tempStr.indexOf(")", tempStr.indexOf("ASCII(")));

        var val = String.fromCharCode(temp);


        tempStr = Public.ReplaceStr(tempStr, "ASCII(" + temp + ")", val, true);
    }

    return tempStr;
}




//
//检查IE版本 7.0以下版本不让登录系统
//
Public.CheckIE = function () {

    var IsOK = true;
    var UA = navigator.userAgent;
    //遨游
    var IsMaxthon = UA.toLowerCase().indexOf('maxthon') > -1 ? true : false;
    if (IsMaxthon) {
        IsOK = false;  //alert("遨游");
    }

    //谷歌
    if (IsOK) {
        var IsChrome = UA.toLowerCase().indexOf('chrome') > -1 ? true : false;
        if (IsChrome) {
            IsOK = false; // alert("谷歌");
        }
    }

    //火狐
    if (IsOK) {
        var IsFirefox = UA.toLowerCase().indexOf('firefox') > -1 ? true : false;
        if (IsFirefox) {
            IsOK = false;  //alert("火狐");
        }
    }

    //360
    if (IsOK) {
        var Is360;
        if (window.external && window.external.twGetRunPath) {
            var r = external.twGetRunPath();
            if (r && r.toLowerCase().indexOf("360") > -1) {
                IsOK = false;  //alert("360");
            }
        }
    }

    //微软IE  
    if (IsOK) {
        var bro = $.browser;
        var banben = parseFloat(bro.version);
        if (!bro.msie || banben < 7.0) {
            IsOK = false;
        }
    }

    if (IsOK) {
        $("#weblogin").show();
        $("#webNoIE").hide();
    } else {
        $("#weblogin").hide();
        $("#webNoIE").show();
    }
}


//
//将数字转换为中文大写
//
Public.ToCn = function (a) {
    if (isNaN(a)) {
        a = 0;
    }
    var _isFushu;
    if (a.constructor == Number)
        a = a + "";
    if (a.indexOf("-") != -1) {
        a = a.replace("-", "");
        _isFushu = 1;
    }
    var b = 9.999999999999E10, f = "\u96f6", h = "\u58f9", g = "\u8d30", e = "\u53c1", k = "\u8086", p = "\u4f0d", q = "\u9646", r = "\u67d2", s = "\u634c", t = "\u7396", l = "\u62fe", d = "\u4f70", i = "\u4edf", m = "\u4e07", j = "\u4ebf", u = "", o = "\u5143", c = "\u89d2", n = "\u5206", v = "\u6574"; a = a.toString(); if (a == "") { MsgHelper.Talert("\u8bf7\u8f93\u5165\u6570\u5b57!"); return "" } if (a.match(/[^,.\d]/) != null) { MsgHelper.Talert("\u8bf7\u4e0d\u8981\u8f93\u5165\u5176\u4ed6\u5b57\u7b26\uff01"); return "" }
    if (a.match(/^((\d{1,3}(,\d{3})*(.((\d{3},)*\d{1,3}))?)|(\d+(.\d+)?))$/) == null) { MsgHelper.Talert("\u975e\u6cd5\u683c\u5f0f\uff01"); return "" } a = a.replace(/,/g, ""); a = a.replace(/^0+/, ""); if (Number(a) > b) { MsgHelper.Talert("\u5bf9\u4e0d\u8d77,\u4f60\u8f93\u5165\u7684\u6570\u5b57\u592a\u5927\u4e86!\u6700\u5927\u6570\u5b57\u4e3a99999999999.99\uff01"); return "" } b = a.split("."); if (b.length > 1) { a = b[0]; b = b[1]; b = b.substr(0, 2) } else { a = b[0]; b = "" } h = new Array(f, h, g, e, k, p, q, r, s, t); l = new Array("", l, d, i); m = new Array("", m, j); n = new Array(c, n); c = ""; if (Number(a) > 0) {
        for (d = j = 0; d < a.length; d++) {
            e = a.length - d - 1; i = a.substr(d,
1); g = e / 4; e = e % 4; if (i == "0") j++; else { if (j > 0) c += h[0]; j = 0; c += h[Number(i)] + l[e] } if (e == 0 && j < 4) c += m[g]
        } c += o
    } if (b != "") for (d = 0; d < b.length; d++) { i = b.substr(d, 1); if (i != "0") c += h[Number(i)] + n[d] } if (c == "") c = f + o; if (b == "") c += v;
    return c = (_isFushu ? "-" : "") + u + c
}

var arr1 = new Array("", " THOUSAND", " MILLION", " BILLION"),
arr2 = new Array("ZERO", "TEN", "TWENTY", "THIRTY", "FORTY", "FIFTY", "SIXTY", "SEVENTY", "EIGHTY", "NINETY"),
arr3 = new Array("ZERO", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE"),
arr4 = new Array("TEN", "ELEVEN", "TWELVE", "THIRTEEN", "FOURTEEN", "FIFTEEN", "SIXTEEN", "SEVENTEEN", "EIGHTEEN", "NINETEEN");
function ToEn(a) {
    var b = a.length, f, h = 0, g = "", e = Math.ceil(b / 3), k = b - e * 3; g = ""; for (f = k; f < b; f += 3) { ++h; num3 = f >= 0 ? a.substring(f, f + 3) : a.substring(0, k + 3); strEng = English(num3); if (strEng != "") { if (g != "") g += ","; g += English(num3) + arr1[e - h] } } return g + ' CARTON(S) ONLY'
}
function English(a) {
    strRet = ""; if (a.length == 3 && a.substr(0, 3) != "000") { if (a.substr(0, 1) != "0") { strRet += arr3[a.substr(0, 1)] + " HUNDRED"; if (a.substr(1, 2) != "00") strRet += " AND " } a = a.substring(1) } if (a.length == 2) if (a.substr(0, 1) == "0") a = a.substring(1); else if (a.substr(0, 1) == "1") strRet += arr4[a.substr(1, 2)]; else { strRet += arr2[a.substr(0, 1)]; if (a.substr(1, 1) != "0") strRet += "-"; a = a.substring(1) } if (a.length == 1 && a.substr(0, 1) != "0") strRet += arr3[a.substr(0, 1)]; return strRet
};





//
//检查某个字符是否在某个字符串中
//
Public.IsCharInString = function (IdList/*原始字符串*/, FindIdArr/*需要判断是否存在的字符串*/) {
    if (IdList == undefined || IdList == "" || IdList == null)
        return false;

    var arr = IdList.split(",");
    var isExists = false;
    for (var a = 0; a < arr.length; a++) {
        var temp = arr[a];
        if (temp == FindIdArr) {
            isExists = true;
            break;
        }
    }
    return isExists;
}

//
//获取一个字符串中根据分隔符分隔后的字符个数
//
Public.GetCharCountBySplit = function (IdList/*字符串*/, _Split/*分隔符，不传默认为，号*/) {
    if (!_Split) {
        _Split = ",";
    }
    var cnt = 0
    if (Public.IsEmpty(IdList, '') == '') {
        cnt = 0;
    }
    var chararr = IdList.split(_Split);
    if (chararr) {
        cnt = chararr.length;
    }
    else { cnt = 0; }
    return cnt;
};


//
//循环执行为控件注册的JS方法， 注册时只注册方法名称并以豆号分隔各个方法,可以带返回值，但如果有多个方法执行只会返回最后一个的值
//
Public.ExecScriptFunction = function (functionList/*方法列表*/, Par/*参数*/) {

    if (!Par)
    { Par = ""; }
    var ReturnValue = true;
    var scriptAll = functionList;
    if (scriptAll) {
        var ScriptArr = scriptAll.split(",");
        if (ScriptArr && ScriptArr.length > 0) {
            for (var index = 0; index < ScriptArr.length; index++) {
                var tempscript = ScriptArr[index];
                tempscript = tempscript + "(" + Par + ");";
                if (tempscript && tempscript != "();" && tempscript.indexOf('undefined') == -1 && tempscript.substr(0, 1) != "(")
                    eval("ReturnValue=" + tempscript);
            }
        }
    }
    if (ReturnValue == undefined) {
        ReturnValue = true;
    }
    return ReturnValue;
};

//
//阻止tree选父级节点
//
function onBeforeNodeSelect(e) {

    if (e.tree.hasChildren(e.node)) {
        e.cancel = true;
    }
}

//
//获取一个对象的数据类型
//
Public.GetType = function (m) {
    var s = Object.prototype.toString.apply(m);
    switch (s) {
        case "[object String]":
            return "string";
        case "[object Number]":
            return "number";
        case "[object Boolean]":
            return "boolean";
        case "[object Array]":
            return "array";
        case "[object Date]":
            return "date";
        case "[object Function]":
            return "function";
        case "[object RegExp]":
            return "regExp";
        case "[object Object]":
            return "object";
        default:
            return "object";
    }
};


/*
处理键盘事件 禁止后退键
*/
function banBackSpace(e) {
    var ev = e || window.event;
    var obj = ev.target || ev.srcElement;


    var t = obj.type || obj.getAttribute('type');

    var vReadOnly = obj.getAttribute('readonly');
    var vEnabled = obj.getAttribute('enabled');
    vReadOnly = (vReadOnly == null) ? false : vReadOnly;
    vEnabled = (vEnabled == null) ? true : vEnabled;

    var flag1 = (ev.keyCode == 8 && (t == "password" || t == "text" || t == "textarea")
                && (vReadOnly == true || vEnabled != true)) ? true : false;

    var flag2 = (ev.keyCode == 8 && t != "password" && t != "text" && t != "textarea")
                ? true : false;

    if (flag2 || flag1) {
        return false;
    }
    return true;
}


/*设置cookie*/
function SetCookie(name, value) {
    var argv = arguments,
         argc = arguments.length,
         expires = (argc > 2) ? argv[2] : null,
         path = (argc > 3) ? argv[3] : '/',
         domain = (argc > 4) ? argv[4] : null,
         secure = (argc > 5) ? argv[5] : false;
    document.cookie = name + "=" + escape(value) + ((expires === null) ? "" : ("; expires=" + expires.toGMTString())) + ((path === null) ? "" : ("; path=" + path)) + ((domain === null) ? "" : ("; domain=" + domain)) + ((secure === true) ? "; secure" : "");
}


/*===========================================================数组操作============================================================*/


/**
* 从对象数组中删除属性为objPropery，值为objValue元素的对象
* @param Array arrPerson 数组对象
* @param String objPropery 对象的属性
* @param String objPropery 对象的值
* @return Array 过滤后数组
例：arrPerson=remove(arrPerson,"id",1);
*/
Public.ArrayRemove = function (arr, objPropery, objValue) {
    return $.grep(arr, function (cur, i) {
        return cur[objPropery] != objValue;
    });
};


/**
* 从对象数组中获取属性为objPropery，值为objValue元素的对象
* @param Array arrPerson 数组对象
* @param String objPropery 对象的属性
* @param String objPropery 对象的值
* @return Array 过滤后的数组
例：arrPerson=get(arrPerson,"id",3);
*/
Public.ArrayGet = function (arr, objPropery, objValue) {

    return $.grep(arr, function (cur, i) {
        return cur[objPropery] == objValue;
    });
};



/*
base64 加解密
*/
(function (scope) {
    var base64EncodeChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    var base64DecodeChars = new Array(
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63,
    52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1,
    -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
    15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1,
    -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
    41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1);

    //base64 编码
    function encode64(str) {
        var out, i, len;
        var c1, c2, c3;
        len = str.length;
        i = 0;
        out = "";
        while (i < len) {
            c1 = str.charCodeAt(i++) & 0xff;
            if (i == len) {
                out += base64EncodeChars.charAt(c1 >> 2);
                out += base64EncodeChars.charAt((c1 & 0x3) << 4);
                out += "==";
                break;
            }
            c2 = str.charCodeAt(i++);
            if (i == len) {
                out += base64EncodeChars.charAt(c1 >> 2);
                out += base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
                out += base64EncodeChars.charAt((c2 & 0xF) << 2);
                out += "=";
                break;
            }
            c3 = str.charCodeAt(i++);
            out += base64EncodeChars.charAt(c1 >> 2);
            out += base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
            out += base64EncodeChars.charAt(((c2 & 0xF) << 2) | ((c3 & 0xC0) >> 6));
            out += base64EncodeChars.charAt(c3 & 0x3F);
        }
        return out;
    }
    //base64 解码
    function decode64(str) {
        var c1, c2, c3, c4;
        var i, len, out;
        len = str.length;
        i = 0;
        out = "";
        while (i < len) {
            /* c1 */
            do {
                c1 = base64DecodeChars[str.charCodeAt(i++) & 0xff];
            } while (i < len && c1 == -1);
            if (c1 == -1)
                break;
            /* c2 */
            do {
                c2 = base64DecodeChars[str.charCodeAt(i++) & 0xff];
            } while (i < len && c2 == -1);
            if (c2 == -1)
                break;
            out += String.fromCharCode((c1 << 2) | ((c2 & 0x30) >> 4));
            /* c3 */
            do {
                c3 = str.charCodeAt(i++) & 0xff;
                if (c3 == 61)
                    return out;
                c3 = base64DecodeChars[c3];
            } while (i < len && c3 == -1);
            if (c3 == -1)
                break;
            out += String.fromCharCode(((c2 & 0XF) << 4) | ((c3 & 0x3C) >> 2));
            /* c4 */
            do {
                c4 = str.charCodeAt(i++) & 0xff;
                if (c4 == 61)
                    return out;
                c4 = base64DecodeChars[c4];
            } while (i < len && c4 == -1);
            if (c4 == -1)
                break;
            out += String.fromCharCode(((c3 & 0x03) << 6) | c4);
        }
        return out;
    }
    function dataEncode(data) {
        if (!data) return "";
        return encode64(escape(data).replace(/\+/g, "%2b"));
    }
    function dataDecode(data) {
        if (!data) return "";
        return unescape(Public.decode64(data));
    }
    scope.encode64 = encode64;
    scope.decode64 = decode64;
    scope.dataEncode = dataEncode;
    scope.dataDecode = dataDecode;
})(Public);


/*=========================================生成唯一码=========================================*/

function UUID() {
    this.id = this.createUUID()
}
UUID.prototype.valueOf = function () {
    return this.id
};
UUID.prototype.toString = function () {
    return this.id
};
UUID.prototype.createUUID = function () {
    var c = new Date(1582, 10, 15, 0, 0, 0, 0);
    var f = new Date();
    var h = f.getTime() - c.getTime();
    var i = UUID.getIntegerBits(h, 0, 31);
    var g = UUID.getIntegerBits(h, 32, 47);
    var e = UUID.getIntegerBits(h, 48, 59) + "2";
    var b = UUID.getIntegerBits(UUID.rand(4095), 0, 7);
    var d = UUID.getIntegerBits(UUID.rand(4095), 0, 7);
    var a = UUID.getIntegerBits(UUID.rand(8191), 0, 7) + UUID.getIntegerBits(UUID.rand(8191), 8, 15) + UUID.getIntegerBits(UUID.rand(8191), 0, 7) + UUID.getIntegerBits(UUID.rand(8191), 8, 15) + UUID.getIntegerBits(UUID.rand(8191), 0, 15);
    return i + g + e + b + d + a
};
UUID.getIntegerBits = function (f, g, b) {
    var a = UUID.returnBase(f, 16);
    var d = new Array();
    var e = "";
    var c = 0;
    for (c = 0; c < a.length; c++) {
        d.push(a.substring(c, c + 1))
    }
    for (c = Math.floor(g / 4) ; c <= Math.floor(b / 4) ; c++) {
        if (!d[c] || d[c] == "") {
            e += "0"
        } else {
            e += d[c]
        }
    }
    return e
};
UUID.returnBase = function (c, d) {
    var e = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
    if (c < d) {
        var b = e[c]
    } else {
        var f = "" + Math.floor(c / d);
        var a = c - f * d;
        if (f >= d) {
            var b = this.returnBase(f, d) + e[a]
        } else {
            var b = e[f] + e[a]
        }
    }
    return b
};
UUID.rand = function (a) {
    return Math.floor(Math.random() * a)
};


/*=========================================生成唯一码=========================================*/


/*ASCII码互转,用于保存数据*/
//
//SQL 注入检查 特殊字符将转为ASCII码
//

//特殊字符转ASCII
Public.StrToASCII = function (str) {

    if (str == null || str == undefined || str.length == 0) {
        return str;
    }
    else {
        str = str.toString();
        str = Public.ReplaceStr(str, "'", "ASCII(39)");
        str = Public.ReplaceStr(str, "\\", "ASCII(92)");
        str = Public.ReplaceStr(str, "[", "ASCII(91)");
        str = Public.ReplaceStr(str, "]", "ASCII(93)");
        str = Public.ReplaceStr(str, ">", "ASCII(62)");
        str = Public.ReplaceStr(str, "<", "ASCII(60)");
        str = Public.ReplaceStr(str, "+", "ASCII(43)");
        str = Public.ReplaceStr(str, "\"", "ASCII(34)");
        return str;
    }
}

//ASCII特殊转字符
Public.ASCIIToStr = function (str) {

    if (str == null || str == undefined || str.length == 0) {
        return str;
    }
    else {
        str = str.toString();
        str = Public.ReplaceStr(str, "ASCII(39)", "'");
        str = Public.ReplaceStr(str, "ASCII(92)", "\\");
        str = Public.ReplaceStr(str, "ASCII(91)", "[");
        str = Public.ReplaceStr(str, "ASCII(93)", "]");
        str = Public.ReplaceStr(str, "ASCII(62)", ">");
        str = Public.ReplaceStr(str, "ASCII(60)", "<");
        str = Public.ReplaceStr(str, "ASCII(43)", "+");
        str = Public.ReplaceStr(str, "ASCII(34)", "\"");
        return str;
    }
}

//获取动态的值
function GetToolBarValue(str, type, pagetype) {
    try {
        var Result = "";
        if (pagetype == "edit") {
            if (type == "#") {
                str = ReplaceGlobalVar(str);
                Result = eval(str);
            } else if (type == "getcol") {
                Result = "Col_" + str + ".MiniControl.getValue()";
                Result = eval(Result);
            } else if (type == "fixvalues") {
                Result = str;
            } else if (type == "cdefinejs") {
                Result = eval(str);
            }
        } else if (pagetype == "list") {
            if (type == "#") {
                if (str == "#programid") {
                    QueryEditInfo();
                    Result = EditProgramID;
                } else if (str == "#billid") {
                    var Sel = grid.getSelecteds();
                    var Values = "";
                    for (var i = 0; i < Sel.length; i++) {
                        Values += Sel[i]["billid"] + ","
                    };
                    Result = Public.TrimEnd(Values, ",");
                } else if (str == "#uid") {
                    Result = eval(str);
                }
            } else if (type == "getcol") {
                var Sel = grid.getSelecteds();
                var Values = "";
                for (var i = 0; i < Sel.length; i++) {
                    Values += Sel[i][str.toLowerCase()] + ","
                };
                Result = Public.TrimEnd(Values, ",");

            } else if (type == "fixvalues") {
                Result = str;

            } else if (type == "cdefinejs") {
                Result = eval(str);
            }
        }
    }
    catch (e) {
        return "Error:" + e.Message;
    }

    return "'" + Result + "'";
}


//替换环境变量
function ReplaceGlobalVar(str) {
    switch (str.toLowerCase()) {
        case "#programid":
            str = "ProgramID";
            break
        case "#billid":
            str = "PrimaryKey";
            break
        case "#uid":
            str = "LoginUser.GetUserID()";
            break
    }

    return str;
}

//特殊字符转ASCII
function ChangeSpeStrToAscII(str) {
    str = str.toString();
    str = Public.ReplaceStr(str, "'", "ASCII(39)");
    str = Public.ReplaceStr(str, "\\", "ASCII(92)");
    str = Public.ReplaceStr(str, "[", "ASCII(91)");
    str = Public.ReplaceStr(str, "]", "ASCII(93)");
    str = Public.ReplaceStr(str, ">", "ASCII(62)");
    str = Public.ReplaceStr(str, "<", "ASCII(60)");
    str = Public.ReplaceStr(str, "+", "ASCII(43)");
    str = Public.ReplaceStr(str, "\"", "ASCII(34)");
    return str;
}

//特殊字符转ASCII
function ChangeSpeAscIIToStr(str) {
    str = str.toString();
    str = Public.ReplaceStr(str, "ASCII(39)", "'");
    str = Public.ReplaceStr(str, "ASCII(92)", "\\");
    str = Public.ReplaceStr(str, "ASCII(91)", "[");
    str = Public.ReplaceStr(str, "ASCII(93)", "]");
    str = Public.ReplaceStr(str, "ASCII(62)", ">");
    str = Public.ReplaceStr(str, "ASCII(60)", "<");
    str = Public.ReplaceStr(str, "ASCII(43)", "+");
    str = Public.ReplaceStr(str, "ASCII(34)", "\"");
    return str;
}

//特殊字符转自定义的特殊字符
function ChangeSpeStrToJosselin(str) {
    str = str.toString();
    str = Public.ReplaceStr(str, "\"", "$james$");
    return str;
}

//特殊字符转自定义的特殊字符
function ChangeSpeJosselinToStr(str) {
    str = str.toString();
    str = Public.ReplaceStr(str, "$james$", "\\\"");
    return str;
}

//Textarea Get
function TextareaValueGet(str) {
    str = str.replace(/\n/g, '_@').replace(/ /g, '_#');
    return str;
}

//Textarea Set
function TextareaValueSet(str) {
    str = str.replace(/_@/g, '\n').replace(/_#/g, ' ');
    return str;
}

function createForm(param, url) {
    //if (!param) return null;

    var _form, _containerDiv = document.createElement("div");
    _containerDiv.style.cssText = "display:none";
    _containerDiv.innerHTML = "<iframe src='about:blank' id='uploadFrame' name='uploadFrame' style='display:none;'></iframe>";
    _form = document.createElement("form");
    _form.method = "post";
    _form.target = "uploadFrame";
    for (var p in param) {
        if (param.hasOwnProperty(p)) {
            _form.innerHTML += "<input type='hidden' name='" + p + "' value='" + param[p] + "' />";
        }
    }
    _containerDiv.appendChild(_form);
    document.body.appendChild(_containerDiv);
    _form.action = url;

    return _form;
}

//多语言加载
Public.LoadLanJs = function () {
    if (lanIndex == 1) {
        document.write('<script src="../../Scripts/Language/english.js"\>' + '<\/script>');
    } else if (lanIndex == 0) {
        document.write('<script src="../../Scripts/Language/chinese.js"\>' + '<\/script>');
    }
}

//多语言替换
Public.LanInit = function () {
    $("lg").each(function (index, obj) {
        var value=$(obj).attr("title");
        $(obj).html(lan[value]);
    })
}

