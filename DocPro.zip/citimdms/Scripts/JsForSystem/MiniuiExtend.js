﻿grid1.getSaveXml = function () {
    var grid1data = grid1.data;
    var SaveResult = "";
    for (var i = 0; i < grid1data.length; i++) {
        SaveResult += "<row>";
        SaveResult += " <id>" + grid1data[i]["id"] + "</id>";
        SaveResult += " <parentid>" + grid1data[i]["parentid"] + "</parentid>";
        SaveResult += " <name>" + grid1data[i]["name"] + "</name>";
        SaveResult += " <editor>" + grid1data[i]["editor"] + "</editor>";
        SaveResult += " <value>" + grid1data[i]["value"] + "</value>";
        SaveResult += "</row>";
        var grid1dataChildren = grid1data[i].children;
        if (grid1dataChildren.length > 0) {
            for (var j = 0; j < grid1dataChildren.length; j++) {
                SaveResult += "<row>";
                SaveResult += " <id>" + grid1dataChildren[j]["id"] + "</id>";
                SaveResult += " <parentid>" + grid1dataChildren[j]["parentid"] + "</parentid>";
                SaveResult += " <name>" + grid1dataChildren[j]["name"] + "</name>";
                SaveResult += " <editor>" + grid1dataChildren[j]["editor"] + "</editor>";
                SaveResult += " <value>" + Public.StrToASCII(grid1dataChildren[j]["value"]) + "</value>";
                SaveResult += " <datasource>" + Public.StrToASCII(grid1dataChildren[j]["datasource"]) + "</datasource>";
                SaveResult += " <listfieldname>" + grid1dataChildren[j]["listfieldname"] + "</listfieldname>";
                SaveResult += "</row>";
            }
        }
    }
    return SaveResult;
}

grid2.getSaveXml = function () {
    var grid2data = grid2.data;
    var SaveResult = "";
    for (var i = 0; i < grid2data.length; i++) {
        SaveResult += "<log>";
        SaveResult += " <id>" + grid2data[i]["id"] + "</id>";
        SaveResult += " <time>" + grid2data[i]["time"] + "</time>";
        SaveResult += " <issue>" + Public.StrToASCII(grid2data[i]["issue"]) + "</issue>";
        SaveResult += " <cause>" + Public.StrToASCII(grid2data[i]["cause"]) + "</cause>";
        SaveResult += " <status>" + grid2data[i]["status"] + "</status>";
        SaveResult += " <resolve>" + Public.StrToASCII(grid2data[i]["resolve"]) + "</resolve>";
        SaveResult += " <attachment>" + grid2data[i]["attachment"] + "</attachment>";
        SaveResult += "</log>";
    }
    return SaveResult;
}

grid1.on("drawcell", function (e) {
    if (e.field == "value") {
        var record = e.record;
        e.cellHtml = !mini.isNull(record.text) ? record.text : record.value;
    }
});

grid1.on("cellbeginedit", function (e) {
    if (e.field == "value") {
        var id = e.record.editor + "Editor";
        var editor = mini.get(id);
        e.editor = editor;
        e.column.editor = editor;
        if (id == "comboboxEditor") {
            e.editor.setData(dataSourceList[e.record.datasource]);
        }
    }
});

grid1.on("cellcommitedit", function (e) {
    var record = e.record;
    if (e.editor.getText) {
        record.text = e.editor.getText();
    } else {
        record.text = e.value;
    }
});