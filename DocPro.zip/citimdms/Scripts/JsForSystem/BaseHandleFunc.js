﻿function BaseHandleFunc() {
    this.Save = function () {
        var obj = this;
        var result = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><root>";
        for (attr in obj) {
            result += "<" + attr + ">";
            result += obj[attr];
            result += "</" + attr + ">";
        }
        result += "</root>";
        return result;
    }
}

