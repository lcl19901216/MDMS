﻿/*
创建：蒋盛珠
功能：用于提示框信息提示，例 Alert Confirm Open.......
时间：2013-1-22
*/

var MsgHelper = new Object();

var MSG = MsgHelper; //简化命名


//显示提示信息  
MsgHelper.ShowTip = function (msg, isok) {

    if (isok == undefined)
        isok = true;

    var _$tip = $("#tipMsg");
    if (isok) {
        _$tip.html("<img src=\"../images/success.png\" height=50 width=60 /><span style='color:Green'>" + msg + "</span>");
    }
    else {
        _$tip.html("<img src=\"../images/error.png\" height=50 width=60 /><span style='color:Red'> " + msg + "</span>")
    }
    _$tip.css({
        top: 0,
        left: $(document.body).width() / 2 - 125
    }).slideDown(500);
    setTimeout(function () {
        $("#tipMsg").slideUp(600);
    }, 1800);
}


//
//弹出框
//
MsgHelper.Talert = function (msg/*提示信息*/, timeout/*延迟显示时间*/, Fn/*回调方法*/) {

    if (!msg) {
        return;
    }

    if (msg.toLowerCase().indexOf("code") != -1) {
        MsgHelper.TalertFormat(msg); return;
    }

    if (timeout != undefined && timeout > 0) {
        //如果是后台弹出需要加上延迟时间
        setTimeout(function () {
            if (Fn && typeof Fn === 'function') {
                if (mini)
                    mini.alert(msg, LGHelper.GetOneMsg("Info29"), Fn);
                else
                    alert(msg);
            }
            else {
                if (mini)
                    mini.alert(msg, LGHelper.GetOneMsg("Info29"));
                else
                    alert(msg);
            }

        }, timeout);
    } else {

        if (Fn && typeof Fn === 'function') {
            if (mini)
                mini.alert(msg, LGHelper.GetOneMsg("Info29"), Fn);
            else
                alert(msg);
        }
        else {
            if (mini)
                mini.alert(msg, LGHelper.GetOneMsg("Info29"));
            else
                alert(msg);
        }
    }
};




//
//功能：格式点位符方式错误提示 针对交互请求返回的错误里包含 ErrorCode 或者信息中包含[列名] 时需要根据情况做动态取数提示
//返回：无
//
MsgHelper.TalertFormat = function (msg) {
    if (!msg) {
        return;
    }

    //如果是返回固定SQL错误就用ErrorCode:SQL001等
    if (msg.toLowerCase().indexOf("errorcode") != -1 && (msg.indexOf("(") != -1 || msg.indexOf(":") != -1)) {
        //如果是固定SQL返回的错误代码
        var temp = msg.toString().substring(10);
        var arr = temp.substring(temp.indexOf('(') + 1).replace(')', '').split(';');
        var cod;
        if (temp.indexOf('(') != -1)
            cod = temp.substring(0, temp.indexOf('('));
        else
            cod = temp;

        msg = LGHelper.GetOneMsg(cod, arr);
        mini.alert(msg, LGHelper.GetOneMsg("Info29"));
        return;
    }

    if (msg.toLowerCase().indexOf("code") == -1) {
        mini.alert(msg, LGHelper.GetOneMsg("Info29"));
        return;
    }




    var TmpMsg;

    try {
        TmpMsg = eval(msg);
    } catch (ex) {
        mini.alert(Public.ReplaceStr(msg, "'", ""), LGHelper.GetOneMsg("Info29"));
        return;
    }

    var ErrorMsg = "";
    if (TmpMsg) {
        for (var index = 0; index < TmpMsg.length; index++) {
            var onemsg = TmpMsg[index];
            if (onemsg.Code) {
                ErrorMsg += LGHelper.GetOneMsg(onemsg.Code, onemsg.Msg) + "<br>"; //根据数组进行参数化取多语言信息
            } else {
                ErrorMsg += onemsg.Msg + "<br>";
            }
        }
    }
    mini.alert(ErrorMsg, LGHelper.GetOneMsg("Info29"));
};




//基于文本打开弹出框
MsgHelper.showMessageBox = function (title/*标题*/, html/*提示类容*/, buttons/*需要显示的按钮*/, callback/*回调方法*/, width, height) {
    var _option = {
        title: title || '',
        buttons: buttons || ["ok", "cancel"],
        iconCls: "mini-messagebox-question",
        html: html || '',
        callback: callback || function (action) { }
    }
    if (width) {
        _option.width = width;
    }
    if (height) {
        _option.height = height;
    }
    if (mini) {
        return mini.showMessageBox(_option);
    }
    return null;
};

//基于url打开弹出框
MsgHelper.open = function (url/*URL*/, title/*标题*/, width/*宽度*/, height/*高度*/, showCloseButton/*是否显示关闭按钮*/, onload/*弹出时触发的事件*/, onclose/*关闭时触发的事件*/) {


    width = parseInt(width);

    height = parseInt(height);

    if (isNaN(width))
        width = 500;

    if (isNaN(height))
        height = 500;

    width = parseFloat(width);

    height = parseFloat(height);

    /*var _option = {
    url: url || '',                             //页面地址
    title: title || '',                         //标题
    iconCls: '',                                //标题图标
    width: width || 400,                        //宽度
    height: height || 300,                      //高度
    allowResize: false,                         //允许尺寸调节
    showCloseButton: showCloseButton || false,  //显示关闭按钮
    showMaxButton: true,                        //显示最大化按钮
    onload: onload || function() { },
    ondestroy: onclose || function(action) { }
    };

    if (mini) {
    return mini.open(_option);
    }*/
    var dialog = parent.openDialog || parent.parent.openDialog;
    if (typeof dialog === 'function')
        dialog(url, title, width, height, showCloseButton, onload, onclose);
    return null;
};


//根据HTML代码弹窗口
MsgHelper.openHtml = function (html/*html*/, title/*标题*/, width/*宽度*/, height/*高度*/, buttons/*显示按钮*/, CallBackFn/*回调事件*/) {
    if (!buttons) {
        buttons = ["ok", "cancel"];
    }

    mini.showMessageBox({
        width: width,
        height: height,
        title: title,
        buttons: buttons,
        message: title,
        html: html,
        showModal: false,
        callback: function (action) {
            CallBackFn(action);
        }
    });
}

//
//确认框
//
MsgHelper.Confirm = function (msg/*提示信息*/, Fn/*回调方法*/, CancelFn/*取消回调方法*/) {

    mini.confirm(msg, "确认提示", function (action) {
        if (action == 'ok') {
            if (typeof Fn === 'function') Fn();
        } else {
            if (typeof CancelFn === 'function')
                CancelFn();
        }
    });
};

//
//文本输入提示框
//
MsgHelper.prompt = function (message, title, callback, multi) {
    mini.prompt(message, title,
     function (action, value) {
         if (typeof callback === 'function')
             callback(action, value);
     },
     multi
   );
}