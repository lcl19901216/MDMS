﻿var PublicJs = new Object();  //公共方法对象
var oMenu;                    //右键菜单对象
var aUl;                      //Ul对象
var aLi;                      //Li对象
var showTimer;                //延时显示
var aDoc;                     //屏幕的长和宽
var maxWidth;                 //最大宽度,适用于右键菜单
var getOffset;                //位移对象
var myDiagram;                //图表对象
var ispaste = false;          //右键显示粘贴
var isproperty = false;       //右键显示属性

//myDiagram.scale 元素的比例,ctrl+鼠标滑轮的效果,可以保存
//var b=tabs.getActiveTab();var c=tabs.getTabBodyEl(b);c.firstElementChild;
PublicJs.RightMemuInit = function () {
    oMenu = document.getElementById("rightMenu");
    aUl = oMenu.getElementsByTagName("ul");
    aLi = oMenu.getElementsByTagName("li");
    showTimer = hideTimer = null;
    aDoc = [document.documentElement.offsetWidth, document.documentElement.offsetHeight];
    oMenu.style.display = "none";

    for (i = 0; i < aLi.length; i++) {
        //为含有子菜单的li加上箭头
        aLi[i].getElementsByTagName("ul")[0] && (aLi[i].className = "sub");
        //鼠标移入
        aLi[i].onmouseover = function () {
            var oThis = this;
            var oUl = oThis.getElementsByTagName("ul");
            //鼠标移入样式
            oThis.className += " active";
            //显示子菜单
            if (oUl[0]) {
                clearTimeout(hideTimer);
                showTimer = setTimeout(function () {
                    for (i = 0; i < oThis.parentNode.children.length; i++) {
                        oThis.parentNode.children[i].getElementsByTagName("ul")[0] &&
                        (oThis.parentNode.children[i].getElementsByTagName("ul")[0].style.display = "none");
                    }
                    oUl[0].style.display = "block";
                    oUl[0].style.top = oThis.offsetTop + "px";
                    oUl[0].style.left = oThis.offsetWidth + "px";
                    setWidth(oUl[0]);
                    //最大显示范围     
                    maxWidth = aDoc[0] - oUl[0].offsetWidth;
                    maxHeight = aDoc[1] - oUl[0].offsetHeight;
                    //防止溢出
                    maxWidth < getOffset.left(oUl[0]) && (oUl[0].style.left = -oUl[0].clientWidth + "px");
                    maxHeight < getOffset.top(oUl[0]) && (oUl[0].style.top = -oUl[0].clientHeight + oThis.offsetTop + oThis.clientHeight + "px")
                }, 300);
            }
        };
        //鼠标移出 
        aLi[i].onmouseout = function () {
            var oThis = this;
            var oUl = oThis.getElementsByTagName("ul");
            //鼠标移出样式
            oThis.className = oThis.className.replace(/\s?active/, "");
            clearTimeout(showTimer);
            hideTimer = setTimeout(function () {
                for (i = 0; i < oThis.parentNode.children.length; i++) {
                    oThis.parentNode.children[i].getElementsByTagName("ul")[0] &&
                    (oThis.parentNode.children[i].getElementsByTagName("ul")[0].style.display = "none");
                }
            }, 300);
        };
    }
}

function init() {
    PublicJs.RightMemuInit();
    if (window.goSamples) goSamples();  // init for these samples -- you don't need to call this
    var draw = go.GraphObject.make;  // for conciseness in defining templates

    myDiagram =
      draw(go.Diagram, "myDiagramDiv",  // must name or refer to the DIV HTML element
        {
            grid: draw(go.Panel, "Grid",
                    draw(go.Shape, "LineH", { stroke: "lightgray", strokeWidth: 0.5 }),
                    draw(go.Shape, "LineH", { stroke: "gray", strokeWidth: 0.5, interval: 10 }),
                    draw(go.Shape, "LineV", { stroke: "lightgray", strokeWidth: 0.5 }),
                    draw(go.Shape, "LineV", { stroke: "gray", strokeWidth: 0.5, interval: 10 })
                  ),
            allowDrop: true,  // must be true to accept drops from the Palette
            "draggingTool.dragsLink": true,
            "draggingTool.isGridSnapEnabled": true,
            "linkingTool.isUnconnectedLinkValid": true,
            "linkingTool.portGravity": 20,
            "relinkingTool.isUnconnectedLinkValid": true,
            "relinkingTool.portGravity": 20,
            "relinkingTool.fromHandleArchetype":
              draw(go.Shape, "Diamond", { segmentIndex: 0, cursor: "pointer", desiredSize: new go.Size(8, 8), fill: "tomato", stroke: "darkred" }),
            "relinkingTool.toHandleArchetype":
              draw(go.Shape, "Diamond", { segmentIndex: -1, cursor: "pointer", desiredSize: new go.Size(8, 8), fill: "darkred", stroke: "tomato" }),
            "linkReshapingTool.handleArchetype":
              draw(go.Shape, "Diamond", { desiredSize: new go.Size(7, 7), fill: "lightblue", stroke: "deepskyblue" }),
            rotatingTool: draw(TopRotatingTool),  // defined below
            "rotatingTool.snapAngleMultiple": 15,
            "rotatingTool.snapAngleEpsilon": 15,
            "undoManager.isEnabled": true
        });

    /*增加节点*/
    function addNodeAndLink(e, obj, arry) {
        removeNode();
        var adornment = obj.part;
        var diagram = e.diagram;

        // get the node data for which the user clicked the button
        var fromNode = adornment.adornedPart;
        var fromData = fromNode.data;
        var x = 90;
        var p = fromNode.location.copy();
        if (fromData.size) {
            x = fromData.size.toString().split(" ")[0];
            y = fromData.size.toString().split(" ")[1];
        }

        for (var i = 0; i < arry.length; i++) {
            // create a new "State" data object, positioned off to the right of the adorned Node
            var toData = { text: arry[i]["type"] };
            p.x = parseFloat(fromNode.position.x) + parseFloat(x) + 50;
            p.y = parseFloat(fromNode.position.y) + parseFloat(40 * i);
            toData.loc = go.Point.stringify(p);  // the "loc" property is a string, not a Point object
            toData.category = "Super";
            toData.source = arry[i]["source"];

            // add the new node data to the model
            var model = diagram.model;
            model.addNodeData(toData);
        }
    }

    /*批量删除节点*/
    function removeNode() {
        var deletenodes = [];
        myDiagram.nodes.each(function (e) {
            if (e.data.category == "Super") {
                deletenodes.push(e.data);
            }
        })
        myDiagram.model.removeNodeDataCollection(deletenodes);
    }

    /*定位到节点*/
    function ViewBoundByNode(toData) {
        var newnode = myDiagram.findNodeForData(toData);
        myDiagram.select(newnode);

        // if the new node is off-screen, scroll the diagram to show the new node
        myDiagram.scrollToRect(newnode.actualBounds);
    }

    // Define a function for creating a "port" that is normally transparent.
    // The "name" is used as the GraphObject.portId, the "spot" is used to control how links connect
    // and where the port is positioned on the node, and the boolean "output" and "input" arguments
    // control whether the user can draw links from or to the port.
    function makePort(name, spot, output, input) {
        // the port is basically just a small transparent square
        return draw(go.Shape, "Circle",
                 {
                     fill: null,  // not seen, by default; set to a translucent gray by showSmallPorts, defined below
                     stroke: null,
                     desiredSize: new go.Size(10, 10),
                     alignment: spot,  // align the port on the main Shape
                     alignmentFocus: spot,  // just inside the Shape
                     portId: name,  // declare this object to be a "port"
                     fromSpot: spot, toSpot: spot,  // declare where links may connect at this port
                     fromLinkable: output, toLinkable: input,  // declare whether the user may draw links to/from here
                     cursor: "pointer"  // show a different cursor to indicate potential link point
                 });
    }

    var nodeSelectionAdornmentTemplate =
      draw(go.Adornment, "Auto",
        draw(go.Shape, { fill: null, stroke: "deepskyblue", strokeWidth: 1.5, strokeDashArray: [4, 2] }),
        draw(go.Placeholder)
      );

    var nodeResizeAdornmentTemplate =
      draw(go.Adornment, "Spot",
        { locationSpot: go.Spot.Right },
        draw(go.Placeholder),
        draw(go.Shape, { alignment: go.Spot.TopLeft, cursor: "nw-resize", desiredSize: new go.Size(6, 6), fill: "lightblue", stroke: "deepskyblue" }),
        draw(go.Shape, { alignment: go.Spot.Top, cursor: "n-resize", desiredSize: new go.Size(6, 6), fill: "lightblue", stroke: "deepskyblue" }),
        draw(go.Shape, { alignment: go.Spot.TopRight, cursor: "ne-resize", desiredSize: new go.Size(6, 6), fill: "lightblue", stroke: "deepskyblue" }),

        draw(go.Shape, { alignment: go.Spot.Left, cursor: "w-resize", desiredSize: new go.Size(6, 6), fill: "lightblue", stroke: "deepskyblue" }),
        draw(go.Shape, { alignment: go.Spot.Right, cursor: "e-resize", desiredSize: new go.Size(6, 6), fill: "lightblue", stroke: "deepskyblue" }),

        draw(go.Shape, { alignment: go.Spot.BottomLeft, cursor: "se-resize", desiredSize: new go.Size(6, 6), fill: "lightblue", stroke: "deepskyblue" }),
        draw(go.Shape, { alignment: go.Spot.Bottom, cursor: "s-resize", desiredSize: new go.Size(6, 6), fill: "lightblue", stroke: "deepskyblue" }),
        draw(go.Shape, { alignment: go.Spot.BottomRight, cursor: "sw-resize", desiredSize: new go.Size(6, 6), fill: "lightblue", stroke: "deepskyblue" })
      );

    var nodeRotateAdornmentTemplate =
      draw(go.Adornment,
        { locationSpot: go.Spot.Center, locationObjectName: "CIRCLE" },
        draw(go.Shape, "Circle", { name: "CIRCLE", cursor: "pointer", desiredSize: new go.Size(7, 7), fill: "lightblue", stroke: "deepskyblue" }),
        draw(go.Shape, { geometryString: "M3.5 7 L3.5 30", isGeometryPositioned: true, stroke: "deepskyblue", strokeWidth: 1.5, strokeDashArray: [4, 2] })
      );

    myDiagram.nodeTemplate =
      draw(go.Node, "Spot",
        { locationSpot: go.Spot.Center, contextMenu: draw(go.Adornment) },
        new go.Binding("location", "loc", go.Point.parse).makeTwoWay(go.Point.stringify),
        { selectable: true, selectionAdornmentTemplate: nodeSelectionAdornmentTemplate },
        { resizable: true, resizeObjectName: "PANEL", resizeAdornmentTemplate: nodeResizeAdornmentTemplate },
        { rotatable: true, rotateAdornmentTemplate: nodeRotateAdornmentTemplate },
        new go.Binding("angle").makeTwoWay(),
        // the main object is a Panel that surrounds a TextBlock with a Shape
        draw(go.Panel, "Auto",
          { name: "PANEL" },
          new go.Binding("desiredSize", "size", go.Size.parse).makeTwoWay(go.Size.stringify),
          draw(go.Shape, "Rectangle",  // default figure
            {
                portId: "", // the default port: if no spot on link data, use closest side
                cursor: "pointer",
                fill: "white",  // default color
                strokeWidth: 2,
                stroke: "black"
            },
            new go.Binding("figure"),
            new go.Binding("fill"),
            new go.Binding("stroke")),
          draw(go.TextBlock,
            {
                font: "bold 11pt Helvetica, Arial, sans-serif",
                margin: 8,
                wrap: go.TextBlock.WrapFit,
                editable: false
            },
            new go.Binding("text").makeTwoWay())
        ),
        // four small named ports, one on each side:
        makePort("T", go.Spot.Top, true, true),
        makePort("L", go.Spot.Left, true, true),
        makePort("R", go.Spot.Right, true, true),
        makePort("B", go.Spot.Bottom, true, true),
        { // handle mouse enter/leave events to show/hide the ports
            mouseEnter: function (e, node) { showSmallPorts(node, true); },
            mouseLeave: function (e, node) { showSmallPorts(node, false); }
        }
      );

    myDiagram.nodeTemplateMap.add("Super",
      draw(go.Node, "Spot",
        { locationSpot: go.Spot.Center },
        new go.Binding("location", "loc", go.Point.parse).makeTwoWay(go.Point.stringify),
        draw(go.Panel, "Auto",
            draw(go.Picture, { cursor: "pointer" },
        new go.Binding("source", "source"))
        )
      ));

    myDiagram.nodeTemplate.selectionAdornmentTemplate =
      draw(go.Adornment, "Spot",
        draw(go.Panel, "Auto",
          draw(go.Shape, { fill: null, stroke: "blue", strokeWidth: 2 }),
          draw(go.Placeholder)  // a Placeholder sizes itself to the selected Node
        ),
        // the button to create a "next" node, at the top-right corner
        draw("Button",
          {
              alignment: go.Spot.BottomRight,
              click: function (e, obj) {
                  StepFloatView(e, obj);
                  //var arry = [{ "type": "excel", "source": "../image/excel.png" }, { "type": "visio", "source": "../image/visio.png" }, { "type": "txt", "source": "../image/txt.png" }];
                  //addNodeAndLink(e, obj, arry);
              }  // this function is defined below
          },
          draw(go.Shape, "PlusLine", { width: 10, height: 10 })
        ) // end button
      ); // end Adornment

    function showSmallPorts(node, show) {
        node.ports.each(function (port) {
            if (port.portId !== "") {  // don't change the default port, which is the big shape
                port.fill = show ? "rgba(0,0,0,.3)" : null;
            }
        });
    }

    var linkSelectionAdornmentTemplate =
      draw(go.Adornment, "Link",
        draw(go.Shape,
          // isPanelMain declares that this Shape shares the Link.geometry
          { isPanelMain: true, fill: null, stroke: "deepskyblue", strokeWidth: 0 })  // use selection object's strokeWidth
      );

    myDiagram.linkTemplate =
      draw(go.Link,  // the whole link panel
        {
            curve: go.Link.JumpOver, adjusting: go.Link.Stretch,
            reshapable: true, relinkableFrom: true, relinkableTo: true,
            toShortLength: 3, routing: go.Link.AvoidsNodes, resegmentable: true,
        },
        new go.Binding("points").makeTwoWay(),
        new go.Binding("curviness"),
        draw(go.Shape,  // the link shape
          { strokeWidth: 1.5 }),
        draw(go.Shape,  // the arrowhead
          { toArrow: "standard", stroke: null }),
        draw(go.Panel, "Auto",
          draw(go.Shape,  // the label background, which becomes transparent around the edges
            {
                fill: draw(go.Brush, "Radial",
                        { 0: "rgb(240, 240, 240)", 0.3: "rgb(240, 240, 240)", 1: "rgba(240, 240, 240, 0)" }),
                stroke: null
            }),
          draw(go.TextBlock, "",  // the label text
            {
                textAlign: "center",
                font: "10pt helvetica, arial, sans-serif",
                margin: 1,
                editable: true  // enable in-place editing
            },
            // editing the text automatically updates the model data
            new go.Binding("text").makeTwoWay())
        )
      );

    myDiagram.nodeTemplateMap.add("Comment",
    draw(go.Node, "Spot",// this needs to act as a rectangular shape for BalloonLink,
        { background: "transparent" },  // which can be accomplished by setting the background.
        new go.Binding("location", "loc", go.Point.parse).makeTwoWay(go.Point.stringify),
        { selectable: true, selectionAdornmentTemplate: nodeSelectionAdornmentTemplate },
        { resizable: true, resizeObjectName: "PANEL", resizeAdornmentTemplate: nodeResizeAdornmentTemplate },
        { rotatable: true, rotateAdornmentTemplate: nodeRotateAdornmentTemplate },
        draw(go.Panel, "Auto",
          { name: "PANEL" },
          draw(go.TextBlock,
            {
                font: "bold 11pt Helvetica, Arial, sans-serif",
                wrap: go.TextBlock.WrapFit,
                editable: false
            },
            new go.Binding("text").makeTwoWay())
        )));

    myDiagram.linkTemplateMap.add("Comment",
      // if the BalloonLink class has been loaded from the Extensions directory, use it
      draw((typeof BalloonLink === "function" ? BalloonLink : go.Link),
        draw(go.Shape,  // the Shape.geometry will be computed to surround the comment node and
                     // point all the way to the commented node
          { stroke: "brown", strokeWidth: 1, fill: "lightyellow" })
      ));

    myDiagram.scale = 0.7;
    load();  // load an initial diagram from some JSON text

    // initialize the Palette that is on the left side of the page
    myPalette =
      draw(go.Palette, "myPaletteDiv",  // must name or refer to the DIV HTML element
        {
            maxSelectionCount: 1,
            nodeTemplateMap: myDiagram.nodeTemplateMap,  // share the templates used by myDiagram
            linkTemplate: // simplify the link template, just in this Palette
              draw(go.Link,
                { // because the GridLayout.alignment is Location and the nodes have locationSpot == Spot.Center,
                    // to line up the Link in the same manner we have to pretend the Link has the same location spot
                    locationSpot: go.Spot.Center,
                    selectionAdornmentTemplate:
                      draw(go.Adornment, "Link",
                        { locationSpot: go.Spot.Center },
                        draw(go.Shape,
                          { isPanelMain: true, fill: null, stroke: "deepskyblue", strokeWidth: 0 }),
                        draw(go.Shape,  // the arrowhead
                          { toArrow: "Standard", stroke: null })
                      )
                },
                {
                    routing: go.Link.AvoidsNodes,
                    curve: go.Link.JumpOver,
                    corner: 5,
                    toShortLength: 4
                },
                new go.Binding("points"),
                draw(go.Shape,  // the link path shape
                  { isPanelMain: true, strokeWidth: 2 }),
                draw(go.Shape,  // the arrowhead
                  { toArrow: "Standard", stroke: null })
              ),
            model: new go.GraphLinksModel([  // specify the contents of the Palette
              { text: "Start", figure: "Circle", fill: "#00AD5F" },
              { text: "Step", figure: "CreateRequest", fill: "#FFCC22", size: "70 70" },
              { text: "DB", figure: "Database", fill: "lightgray" },
              { text: "CK", figure: "Diamond", fill: "lightskyblue" },
              { text: "End", figure: "Circle", fill: "#CE0620" },
              { text: "Comment", figure: "RoundedRectangle", fill: "lightyellow" }
            ], [
              // the Palette also has a disconnected Link, which the user can drag-and-drop
              { points: new go.List(go.Point).addAll([new go.Point(0, 0), new go.Point(30, 0), new go.Point(30, 40), new go.Point(60, 40)]) }
            ])
        });

    myDiagram.contextMenu = draw(go.Adornment);

    // Override the ContextMenuTool.showContextMenu and hideContextMenu methods
    // in order to modify the HTML appropriately.
    var cxTool = myDiagram.toolManager.contextMenuTool;

    // This is the actual HTML context menu:
    var cxElement = document.getElementById("rightMenu");

    // We don't want the div acting as a context menu to have a (browser) context menu!
    cxElement.addEventListener("contextmenu", function (e) {
        this.focus();
        e.preventDefault();
        return false;
    }, false);

    //cxElement.addEventListener("blur", function (e) {
    //    cxTool.stopTool();
    //    // maybe start another context menu
    //    if (cxTool.canStart()) {
    //        myDiagram.currentTool = cxTool;
    //        cxTool.doMouseUp();
    //    }
    //}, false);

    cxElement.tabIndex = "1";

    cxTool.showContextMenu = function (contextmenu, obj) {
        var diagram = this.diagram;
        if (diagram === null) return;

        // Hide any other existing context menu
        if (contextmenu !== this.currentContextMenu) {
            this.hideContextMenu();
        }

        var event = event || window.event;
        oMenu.style.display = "block";

        var cmd = diagram.commandHandler;
        var objExists = obj !== null;

        $("#cut").css("display", objExists && cmd.canCutSelection() ? "block" : "none");
        $("#copy").css("display", objExists && cmd.canCopySelection() ? "block" : "none");
        $("#paste").css("display", cmd.canPasteSelection() && ispaste == true ? "block" : "none");
        $("#delete").css("display", objExists && cmd.canDeleteSelection() ? "block" : "none");

        oMenu.style.top = event.clientY + "px";
        oMenu.style.left = event.clientX + "px";
        oMenu.style.zIndex = 200;
        setWidth(aUl[0]);
        //最大显示范围
        maxWidth = aDoc[0] - oMenu.offsetWidth;
        maxHeight = aDoc[1] - oMenu.offsetHeight;
        //防止菜单溢出
        oMenu.offsetTop > maxHeight && (oMenu.style.top = maxHeight + "px");
        oMenu.offsetLeft > maxWidth && (oMenu.style.left = maxWidth + "px");

        this.currentContextMenu = contextmenu;
    }

    cxTool.hideContextMenu = function () {
        if (this.currentContextMenu === null) return;
        oMenu.style.display = "none"
        this.currentContextMenu = null;
    }

    /*初始化节点样式*/
    myDiagram.nodes.each(function (e) {
        var key = e.data.key;
        if (stepsattr.hasOwnProperty(key) && stepsattr[key]["steptype"] == "visio") {
            setProperty(e.data, "stroke", "red");
        }
    })
}

function cxcommand(val) {
    var diagram = myDiagram;
    if (!(diagram.currentTool instanceof go.ContextMenuTool)) return;
    switch (val) {
        case "cut": diagram.commandHandler.cutSelection(); ispaste = true; break;
        case "copy": diagram.commandHandler.copySelection(); ispaste = true; break;
        case "paste": diagram.commandHandler.pasteSelection(diagram.lastInput.documentPoint); break;
        case "delete": diagram.commandHandler.deleteSelection(); break;
        case "property":
            if (diagram.selection.count > 1) {
                mini.alert("设置属性时,不可以选择多个节点");
            } else {
                var currentnode = myDiagram.selection.first();
                var key = currentnode.data["key"];
                var getcurrnodeattr = stepsattr[key];
                var stepid = key;
                var stepname = !getcurrnodeattr ? "" : getcurrnodeattr["stepname"];
                var steptype = !getcurrnodeattr ? "" : getcurrnodeattr["steptype"];
                var targetfile = !getcurrnodeattr ? "" : getcurrnodeattr["targetfile"];
                var targetpagetype = !getcurrnodeattr ? "" : getcurrnodeattr["targetpagetype"];

                mini.get("stepid").setValue(stepid);
                mini.get("stepname").setValue(stepname);
                mini.get("steptype").setValue(steptype);
                mini.get("targetfile").setValue(targetfile);
                mini.get("targetpagetype").setValue(targetpagetype);
                CreateStepAttrShape(stepid);
            }
            break;
    }
    diagram.currentTool.stopTool();
}

//生成节点属性的图形
function CreateStepAttrShape(stepid) {
    $("#stepsattr [class='dynamicshape']").remove();
    try {
        var visioshapearray = stepsattr[stepid]["shape"]["visios"];
        var targetfile = stepsattr[stepid]["targetfile"];
        var targetpagetype = stepsattr[stepid]["targetpagetype"];
    } catch (e) {
        return;
    }

    //生成visio
    for (var i = 0; i < visioshapearray.length; i++) {
        var visioname = visioshapearray[i]["visio"]["name"];

        $("#stepsattr").append('<li class="dynamicshape"><img src="image/visio.png" style="cursor: pointer" onclick="ZQShape(this)" visioname="' + visioname + '" targetfile="' + targetfile + '" targetpagetype="' + targetpagetype + '" /><font color=red>' + visioname + '</font></li>');
    }
}

//图标钻取链接
function ZQShape(e) {
    var visioname = $(e).attr("visioname");
    var targetfile = $(e).attr("targetfile");
    var targetpagetype = $(e).attr("targetpagetype");

    parent.addTab(visioname, "FlowChart.aspx?filename=" + targetfile + "&visioname=" + visioname + "&pagetype=" + targetpagetype);
}

// Show the diagram's model in JSON format that the user may edit
function save() {
    saveDiagramProperties();  // do this first, before writing to JSON
    document.getElementById("mySavedModel").value = myDiagram.model.toJson();
    myDiagram.isModified = false;
}
function load() {
    myDiagram.model = go.Model.fromJson(document.getElementById("mySavedModel").value);
    loadDiagramProperties();  // do this after the Model.modelData has been brought into memory
}

function saveDiagramProperties() {
    myDiagram.model.modelData.position = go.Point.stringify(myDiagram.position);
}
function loadDiagramProperties(e) {
    // set Diagram.initialPosition, not Diagram.position, to handle initialization side-effects
    var pos = myDiagram.model.modelData.position;
    if (pos) myDiagram.initialPosition = go.Point.parse(pos);
}

//取li中最大的宽度, 并赋给同级所有li 
function setWidth(obj) {
    maxWidth = 0;
    for (i = 0; i < obj.children.length; i++) {
        var oLi = obj.children[i];
        var iWidth = oLi.clientWidth - parseInt(oLi.currentStyle ? oLi.currentStyle["paddingLeft"] : getComputedStyle(oLi, null)["paddingLeft"]) * 2
        if (iWidth > maxWidth) maxWidth = iWidth;
    }
    for (i = 0; i < obj.children.length; i++) obj.children[i].style.width = maxWidth + "px";
}

//修改节点属性
function setProperty(nodedata, property, value) {
    myDiagram.model.setDataProperty(nodedata, property, value);
}

function TopRotatingTool() {
    go.RotatingTool.call(this);
}


go.Diagram.inherit(TopRotatingTool, go.RotatingTool);

/** @override */
TopRotatingTool.prototype.updateAdornments = function (part) {
    go.RotatingTool.prototype.updateAdornments.call(this, part);
    var adornment = part.findAdornment("Rotating");
    if (adornment !== null) {
        adornment.location = part.rotateObject.getDocumentPoint(new go.Spot(0.5, 0, 0, -30));  // above middle top
    }
};

/** @override */
TopRotatingTool.prototype.rotate = function (newangle) {
    go.RotatingTool.prototype.rotate.call(this, newangle + 90);
};

getOffset = {
    top: function (obj) {
        return obj.offsetTop + (obj.offsetParent ? arguments.callee(obj.offsetParent) : 0)
    },
    left: function (obj) {
        return obj.offsetLeft + (obj.offsetParent ? arguments.callee(obj.offsetParent) : 0)
    }
};

//修改stepname时,动态更改相应节点名称
function SetStepName(e) {
    var newstepname = e.value;
    var stepid = mini.get("stepid").getValue();
    var currentnode = myDiagram.model.findNodeDataForKey(stepid);
    setProperty(currentnode, "text", newstepname);
}

//根据不同的节点类型改变边框颜色
function SetStepType(e) {
    var steptypevalue = e.value;
    var stepid = mini.get("stepid").getValue();
    var currentnode = myDiagram.model.findNodeDataForKey(stepid);
    if (steptypevalue == "visio") {
        setProperty(currentnode, "stroke", "red");
    } else {
        setProperty(currentnode, "stroke", "black");
    }
}

//生成step信息的悬浮框
function StepFloatView(e, obj) {
    var stepdechtml = "";
    var steptablehtml = "<table>";
    var adornment = obj.part;
    var diagram = e.diagram;

    // get the node data for which the user clicked the button
    var fromNode = adornment.adornedPart;
    var fromData = fromNode.data;
    var x = e.Vp.clientX;
    var y = e.Vp.clientY;

    $("#stepdesposition").css({ "left": x, "top": y });
    $("#stepdes").children().remove();

    var currentstep = stepsattr[fromData["key"]];
    var hrefLink = "JobEditPage.aspx";

    if (currentstep["steptype"] == "visio") {
        var forminput = '<a href="javascript:parent.addTab(\'' + currentstep["targetfile"] + '\',\'' + hrefLink + '?filename=' + currentstep["targetfile"] + '&pagetype=' + currentstep["targetpagetype"] + '&status=edit\')">' + currentstep["targetfile"] + '</a>';
        steptablehtml += forminput;
    }
    else {
        if (stepsattr[fromData["key"]].hasOwnProperty("detail")) {
            var details = stepsattr[fromData["key"]]["detail"];

            for (var i = 0; i < details.length; i++) {
                var forminput = "";
                forminput += "<tr><td>" + details[i]["name"] + "</td>"
                if (details[i]["editor"] == "textarea") {
                    forminput += "<td><textarea style='width:215px' >" + details[i]["value"] + "</textarea></td></tr>";
                } else {
                    forminput += "<td><input type='" + details[i]["editor"] + "' value='" + details[i]["value"] + "' ></td></tr>";
                }
                steptablehtml += forminput;
            }
        }
    }
    steptablehtml += "</table>";

    stepdechtml = '<div class="af-wrapper">' +
        '<h3>节点详细信息</h3>' +
        '<input id="af-showreq" class="af-show-input" type="checkbox" name="showreq">' +
        '<form class="af-form" id="af-form" novalidate="novalidate">' + steptablehtml +
        '</form></div>';

    $("#stepdes").append(stepdechtml);

    var floatPosition = "6-8";
    if (y <= 150) {
        floatPosition = "3-2";
    } else if (y > 450) {
        floatPosition = "2-3";
    }

    $("#stepdesposition").powerFloat({
        target: $("#stepdes"),
        position: floatPosition,
        width: "350px"
    });
}