﻿using Citi.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class JobListPage : System.Web.UI.Page
{
    private string PageHtml = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        string pagetype = Request["pagetype"];
        PageHtml = getHtmlForKinds(pagetype);
        ListPageHtml.Text = PageHtml;
    }

    //获取不同类型的列表页html
    private string getHtmlForKinds(string pagetype)
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("<div id=\"datagrid\" class=\"mini-datagrid\" style=\"width: 100%; height: 500px\" url=\"../Ashx/HandlerData.ashx\" ")
       .Append("idfield=\"id\" allowresize=\"true\" pagesize=\"100\" allowcelledit=\"false\" allowcellselect=\"true\" showfilterrow=\"true\" ")
       .Append("multiselect=\"true\" allowcellvalid=\"false\" allowResizeColumn=\"false\" allowSortColumn=\"false\" allowMoveColumn=\"false\" >");

        sb.Append("<div property=\"columns\"> <div type=\"checkcolumn\" headercls=\"grid_header\" headeralign=\"center\"> </div> <div field=\"id\" width=\"100\" headeralign=\"center\" headercls=\"grid_header\"> ID </div>");

        string columnHtml = getHtmlContent(pagetype);

        sb.Append(columnHtml).Append("</div>").Append("</div>");

        return sb.ToString();
    }

    //获取不同类型的列表页html明细内容
    private string getHtmlContent(string pagetype)
    {
        string result = string.Empty;
        string columnName = string.Empty;
        string columnNameLg = string.Empty;
        string filter = "<input id=\"{0}\" property=\"filter\" class=\"mini-textbox\" onvaluechanged=\"onFilterChanged\" style=\"width: 100%;\" />";
        string eachfield = string.Empty;
        XmlDocument xd = new XmlDocument();
        switch (pagetype)
        {
            case "global":
                xd = IOHandle.ReadFileToXmlObject("~/xml/config/Fields/globalfield.xml");
                break;
            case "job":
                xd = IOHandle.ReadFileToXmlObject("~/xml/config/Fields/jobfield.xml");
                break;
            case "flow":
                xd = IOHandle.ReadFileToXmlObject("~/xml/config/Fields/flowfield.xml");
                break;
            case "normal":
                xd = IOHandle.ReadFileToXmlObject("~/xml/config/Fields/normalfield.xml");
                break;
        }

        XmlNodeList nodes = xd.SelectNodes("/root/rows/row");

        foreach (XmlNode node in nodes)
        {
            if (node["islistshow"] != null && node["islistshow"].InnerText == "1")
            {
                eachfield = "<div ";
                XmlNode listnode = node.SelectSingleNode("listfield");
                XmlNodeList childrennodes = listnode.ChildNodes;

                foreach (XmlNode childrennode in childrennodes)
                {
                    if (childrennode.Name == "columnname")
                    {
                        columnName = childrennode.InnerText;
                        continue;
                    }

                    if (childrennode.Name == "field")
                    {
                        columnNameLg = "<lg title=\"" + childrennode.InnerText + "\">";
                        filter = string.Format(filter, childrennode.InnerText + "filter");
                    }

                    eachfield += childrennode.Name + "=\"" + childrennode.InnerText + "\" ";
                }
                columnName = columnNameLg + columnName + "</lg>";
                eachfield += ">" + columnName + filter + "</div> ";
                result += eachfield;
                eachfield = string.Empty;
            }
        }
        return result;
    }
}