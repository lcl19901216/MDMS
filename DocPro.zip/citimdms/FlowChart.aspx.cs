﻿using Citi.Util;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Linq;

public partial class FlowChart : System.Web.UI.Page
{
    public string VisioData = string.Empty;
    public string VisioSetpsAttr = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpRequest request = HttpContext.Current.Request;
        string filename = request["filename"];
        string visioname = request["visioname"];
        string pagetype = request["pagetype"];
        VisioData = GetVisioData(filename, visioname, pagetype);
        VisioSetpsAttr = GetStepObject(filename, visioname, pagetype);
    }

    //生成节点对象
    private string GetStepObject(string filename, string visioname, string pagetype)
    {
        string oppPath = IOHandle.oppPath(pagetype, ModelPath.Data);

        string targetshape = "";
        string targetdetail = "";
        string data = "{";
        XmlDocument xd = IOHandle.ReadFileToXmlObject(oppPath + filename);

        XmlNode node = xd.SelectSingleNode("/root/detail/visio[@visioname='" + visioname + "']");

        XmlNodeList steps = node.SelectNodes("step");
        foreach (XmlNode step in steps)
        {
            string stepid = step["stepid"].InnerText;
            string stepname = step["stepname"].InnerText;
            string targetfile, targetpagetype;
            string steptype = step["steptype"].InnerText;
            if (steptype == "visio")
            {
                targetfile = step["targetfile"].InnerText;
                targetpagetype = step["targetpagetype"].InnerText;
            }
            else
            {
                targetfile = filename;
                targetpagetype = pagetype;
                XmlNode stepdetails = step.SelectSingleNode("detail");
                targetdetail = GetDetail(stepdetails);
            }

            targetshape = GetVisio(targetfile, targetpagetype);

            if (string.IsNullOrEmpty(targetshape)) { targetshape = "[]"; }
            if (string.IsNullOrEmpty(targetdetail)) { targetdetail = "[]"; }
            data += "\"" + stepid + "\":{\"stepname\":\"" + stepname + "\",\"steptype\":\"" + steptype + "\",\"targetfile\":\"" + targetfile + "\",\"targetpagetype\":\""
                + targetpagetype + "\",\"shape\":" + targetshape + ",\"detail\":" + targetdetail + "},";

        }
        data = data.TrimEnd(',');

        data += "}";
        return data;
    }

    //拼接Detail
    private string GetDetail(XmlNode stepdetails)
    {
        string data = string.Empty;

        foreach (XmlNode stepdetail in stepdetails)
        {
            data += "{\"name\":\"" + stepdetail.Name + "\",\"editor\":\"" + stepdetail.Attributes["editor"].InnerText + "\",\"value\":\"" + stepdetail.InnerText + "\"},";
        }

        return "[" + data.TrimEnd(',') + "]";
    }

    //拼接Visio节点里面的visio
    private string GetVisio(string filename, string pagetype)
    {
        string visiodata = string.Empty;

        string oppPath = IOHandle.oppPath(pagetype, ModelPath.Data);

        XmlDocument xd = IOHandle.ReadFileToXmlObject(oppPath + filename);
        XmlNodeList visionodes = xd.SelectNodes("/root/detail/visio");

        //拼接Visio
        foreach (XmlNode visionode in visionodes)
        {
            visiodata += "{\"visio\":{\"name\":\"" + visionode.Attributes["visioname"].Value + "\"}},";
        }
        visiodata = visiodata.TrimEnd(',');

        string data = "{\"visios\":[" + visiodata + "]}";

        return data;
    }

    //读取数据
    private string GetVisioData(string filename, string visioname, string pagetype)
    {
        string data = string.Empty;

        string oppPath = IOHandle.oppPath(pagetype, ModelPath.Data);

        XmlDocument xd = IOHandle.ReadFileToXmlObject(oppPath + filename);

        XmlNode node = xd.SelectSingleNode("/root/detail/visio[@visioname='" + visioname + "']");

        XmlNode visiodata = node.SelectSingleNode("location");
        data = visiodata.InnerText;

        return data;
    }
}