﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml;

namespace Citi.Util
{
    public class IOHandle
    {
        //读取文件成XML对象
        public static XmlDocument ReadFileToXmlObject(string filename)
        {
            string path = HttpContext.Current.Server.MapPath(filename);
            FileInfo fileinfo = new FileInfo(path);

            FileStream fs = fileinfo.Open(FileMode.Open, FileAccess.Read);
            XmlDocument xd = new XmlDocument();
            xd.Load(fs);
            fs.Dispose();

            return xd;
        }

        public static XmlDocument ReadFileToXmlObject(FileInfo fileinfo)
        {
            FileStream fs = fileinfo.Open(FileMode.Open, FileAccess.Read);
            XmlDocument xd = new XmlDocument();
            xd.Load(fs);
            fs.Dispose();

            return xd;
        }

        public static string oppPath(string pagetype, ModelPath model)
        {
            string oppPath = string.Empty;
            if (ModelPath.Data == model)
            {
                switch (pagetype)
                {
                    case "global":
                        oppPath = "~/xml/data/global/";
                        break;
                    case "job":
                        oppPath = "~/xml/data/job/";
                        break;
                    case "flow":
                        oppPath = "~/xml/data/flow/";
                        break;
                    case "normal":
                        oppPath = "~/xml/data/normal/";
                        break;
                }
            }
            else if (ModelPath.Model == model)
            {
                switch (pagetype)
                {
                    case "global":
                        oppPath = "~/xml/config/Fields/globalfield.xml";
                        break;
                    case "job":
                        oppPath = "~/xml/config/Fields/jobfield.xml";
                        break;
                    case "flow":
                        oppPath = "~/xml/config/Fields/flowfield.xml";
                        break;
                    case "normal":
                        oppPath = "~/xml/config/Fields/normalfield.xml";
                        break;
                }
            }
            return oppPath;
        }

        //替换节点
        public static string LocalNameReplace(string str)
        {
            string newstr = "";
            switch (str)
            {
                case "root":
                    newstr = "根结点";
                    break;
                case "rows":
                    newstr = "基础属性";
                    break;
                case "row":
                    newstr = "行";
                    break;
                case "id":
                    newstr = "ID";
                    break;
                case "parentid":
                    newstr = "上级ID";
                    break;
                case "name":
                    newstr = "名称";
                    break;
                case "editor":
                    newstr = "控件类型";
                    break;
                case "value":
                    newstr = "内容";
                    break;
                case "islistshow":
                    newstr = "列表显示";
                    break;
                case "listfieldname":
                    newstr = "列表显示名称";
                    break;
                case "detail":
                    newstr = "明细";
                    break;
                case "visio":
                    newstr = "流程图";
                    break;
                case "step":
                    newstr = "节点";
                    break;
                case "stepid":
                    newstr = "节点ID";
                    break;
                case "stepname":
                    newstr = "节点名称";
                    break;
                case "steptype":
                    newstr = "节点类型";
                    break;
                case "targetfile":
                    newstr = "跳转文件名称";
                    break;
                case "targetpagetype":
                    newstr = "跳转文件类型";
                    break;
                case "location":
                    newstr = "流程图明细信息";
                    break;
                case "solve":
                    newstr = "错误查看";
                    break;
                case "errorlog":
                    newstr = "错误日志";
                    break;
                case "log":
                    newstr = "日志行";
                    break;
                case "time":
                    newstr = "日期";
                    break;
                case "issue":
                    newstr = "问题描述";
                    break;
                case "cause":
                    newstr = "引起的原因";
                    break;
                case "status":
                    newstr = "状态";
                    break;
                case "resolve":
                    newstr = "解决情况";
                    break;
                case "attachment":
                    newstr = "附件";
                    break;
                case "relation":
                    newstr = "上下游关联";
                    break;
                case "flow":
                    newstr = "关联流程";
                    break;
                case "upstream":
                    newstr = "上游";
                    break;
                case "downstream":
                    newstr = "下游";
                    break;
            }
            return newstr;
        }

        public static string StrToASCII(string str)
        {
            str = str.Replace("'", "ASCII(39)");
            str = str.Replace("\\", "ASCII(92)");
            str = str.Replace("[", "ASCII(91)");
            str = str.Replace("]", "ASCII(93)");
            str = str.Replace(">", "ASCII(62)");
            str = str.Replace("<", "ASCII(60)");
            str = str.Replace("+", "ASCII(43)");
            str = str.Replace("\"", "ASCII(34)");
            return str;
        }

        public static string ASCIIToStr(string str)
        {
            str = str.Replace("ASCII(39)", "'");
            str = str.Replace("ASCII(92)", "\\");
            str = str.Replace("ASCII(91)", "[");
            str = str.Replace("ASCII(93)", "]");
            str = str.Replace("ASCII(62)", ">");
            str = str.Replace("ASCII(60)", "<");
            str = str.Replace("ASCII(43)", "+");
            str = str.Replace("ASCII(34)", "\"");
            return str;
        }

        public static void DownLoadFile(string strFileName, string newName)
        {
            if (!System.IO.File.Exists(strFileName))
            {
                throw new Exception("该文件不存在，或已被移出");
                return;
            }

            HttpResponse _response = HttpContext.Current.Response;
            FileStream fs = new FileStream(strFileName, FileMode.Open);
            byte[] bytes = new byte[(int)fs.Length];
            fs.Read(bytes, 0, bytes.Length);
            fs.Close();
            _response.ContentType = "application/octet-stream";
            //通知浏览器下载文件而不是打开
            _response.AddHeader("Content-Disposition", "attachment;  filename=" + HttpContext.Current.Server.UrlPathEncode(newName));
            _response.BinaryWrite(bytes);
            _response.Flush();
            _response.End();
        }
    }

    public enum ModelPath
    {
        Data = 0,
        Model = 1
    }
}
