﻿using Microsoft.AspNet.SignalR;
using Microsoft.CSharp;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Citi.Util
{
    public class SignalR
    {
        public static void SendMessage(string msg, string id)
        {
            IHubContext chat = GlobalHost.ConnectionManager.GetHubContext<PushHub>();
            chat.Clients.All.notice(msg, id);
        }
    }
}
