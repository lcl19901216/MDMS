﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Xml.Linq;

namespace Citi.Util
{
    /// <summary>
    ///功能：用于对一些基本数据类型转换，可以用来规避强转意外失败
    /// </summary>
    public class ConvertHelper
    {
        public ConvertHelper()
        { }

        /// <summary>
        /// 字符串转为INT32 型
        /// </summary>
        /// <param name="s">需转换字符串</param>
        /// <returns>返回INT型，转换失败返回 0</returns>
        public static int ToInt32(object s)
        {
            int result = 0;
            if (s != null && s != DBNull.Value && !string.IsNullOrEmpty(s.ToString()))
            {
                if (s.ToString().Equals("True", StringComparison.CurrentCultureIgnoreCase))
                    result = 1;
                else if (s.ToString().Equals("False", StringComparison.CurrentCultureIgnoreCase))
                    result = 0;
                else
                    int.TryParse(s.ToString(), out result);
            }
            return result;
        }

        /// <summary>
        /// 字符串转为Boll 型
        /// </summary>
        /// <param name="s">需转换字符串</param>
        /// <returns>返回boll型，转换失败返回 false</returns>
        public static bool ToBoolean(object s)
        {
            bool result = false;
            if (s != null && s != DBNull.Value && !string.IsNullOrEmpty(s.ToString()))
            {
                if (s.ToString().Equals("True", StringComparison.CurrentCultureIgnoreCase))
                    result = true;
                else if (s.ToString().Equals("False", StringComparison.CurrentCultureIgnoreCase))
                    result = false;
                else if (s.ToString().Equals("1"))
                    result = true;
                else if (s.ToString().Equals("1"))
                    result = false;
            }
            return result;
        }


        /// <summary>
        /// 字符串转为日期类型
        /// </summary>
        /// <param name="s">需转换字符串</param>
        /// <returns>返回日期，转换失败返回 0001-01-01</returns>
        public static DateTime ToDateTime(object s)
        {
            DateTime result = new DateTime(1, 1, 1);
            if (s != null && s != DBNull.Value && !string.IsNullOrEmpty(s.ToString()))
            {
                DateTime.TryParse(s.ToString(), out result);
            }
            return result;
        }

        /// <summary>
        /// 把日期转换为字符串
        /// </summary>
        /// <param name="s">需转换字符串</param>
        /// <param name="format"></param>
        /// <returns>返回字符串，转换失败返回 0001-01-01</returns>
        public static string ToDateStr(object s, string format)
        {
            DateTime result = new DateTime(1, 1, 1);
            if (s != null && s != DBNull.Value && !string.IsNullOrEmpty(s.ToString()))
            {
                DateTime.TryParse(s.ToString(), out result);
            }
            else
            {
                return string.Empty;
            }
            return result.ToString(format);
        }

        /// <summary>
        /// 字符串转为float 型
        /// </summary>
        /// <param name="s">需转换字符串</param>
        /// <returns>返回float型，转换失败返回 0</returns>
        public static float ToFloat(object s)
        {
            float result = 0;
            if (s != null && s != DBNull.Value && !string.IsNullOrEmpty(s.ToString()))
            {
                float.TryParse(s.ToString(), out result);
            }
            return result;
        }

        /// <summary>
        /// 字符串转为decimal 型
        /// </summary>
        /// <param name="s">需转换字符串</param>
        /// <returns>返回decimal型，转换失败返回 0</returns>
        public static decimal ToDecimal(object s)
        {
            decimal result = 0;
            if (s != null && s != DBNull.Value && !string.IsNullOrEmpty(s.ToString()))
            {
                decimal.TryParse(s.ToString(), out result);
            }
            return result;
        }

        /// <summary>
        /// 字符串转为double 型
        /// </summary>
        /// <param name="s">需转换字符串</param>
        /// <returns>返回double型，转换失败返回 0</returns>
        public static double ToDouble(object s)
        {
            double result = 0;
            if (s != null && s != DBNull.Value && !string.IsNullOrEmpty(s.ToString()))
            {
                double.TryParse(s.ToString(), out result);
            }
            return result;
        }



        /// <summary>
        ///对象转为String类型
        /// </summary>
        /// <param name="s">需转换的对象</param>
        /// <returns>返回string型，转换失败返回 string.empty</returns>
        public static string ToString(object s)
        {
            if (s == null || string.IsNullOrEmpty(s.ToString()))
                return string.Empty;
            else
                return s.ToString();
        }
    }
}