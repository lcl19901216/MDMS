﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace Citi.Util
{
    /// <summary>
    ///JsonUtil 的摘要说明
    /// </summary>
    public class JsonUtil
    {
        private JsonUtil() { }

        /*返回 json数组   格式为  [{name1:value1, name2:value2}]   */
        public static string ToJsArray(DataTable dt)
        {
            if (dt == null || dt.Rows.Count == 0)
            {
                return "[]";
            }
            StringBuilder _json = new StringBuilder();
            _json.Append("[");
            for (int i = 0, lr = dt.Rows.Count; i < lr; i++)
            {
                _json.Append("{");
                for (int j = 0, lc = dt.Columns.Count; j < lc; j++)
                {
                    _json.Append("\"");
                    _json.Append(ConvertHelper.ToString(dt.Columns[j].ColumnName).ToLower());
                    _json.Append("\":\"");
                    _json.Append(StrReplace(ConvertHelper.ToString(dt.Rows[i][j])));
                    _json.Append("\"");
                    if (j < lc - 1)
                    {
                        _json.Append(",");
                    }
                }
                _json.Append("}");
                if (i < lr - 1)
                {
                    _json.Append(",");
                }
            }
            _json.Append("]");
            return _json.ToString();
        }
        /*返回 通用json  格式为  {total:0,data:[{}]}*/
        public static string ToJson(DataTable dt, int total)
        {
            if (dt != null && dt.Rows.Count > 0)
            {
                StringBuilder Json = new StringBuilder();
                Json.Append("{\"total\":").Append(total).Append(",");
                Json.Append("\"data\":[");
                for (int i = 0, lr = dt.Rows.Count; i < lr; i++)
                {
                    Json.Append("{");
                    for (int j = 0, lc = dt.Columns.Count; j < lc; j++)
                    {
                        Json.Append("\"" + ConvertHelper.ToString(dt.Columns[j].ColumnName).ToLower() + "\":\"" + StrReplace(ConvertHelper.ToString(dt.Rows[i][j])) + "\"");
                        if (j < lc - 1)
                        {
                            Json.Append(",");
                        }
                    }
                    Json.Append("}");
                    if (i < lr - 1)
                    {
                        Json.Append(",");
                    }
                }
                Json.Append("]}");
                return Json.ToString();
            }
            return "{\"total\":0,\"data\":[]}";
        }
        //转换 json tree
        public static string ToJsonTree(DataTable dt, TreeAttr attr)
        {
            if (attr == null)
            {
                throw new ArgumentException("未指定节点对象属性");
            }
            if (dt == null || dt.Rows.Count == 0)
            {
                return "[]";
            }

            StringBuilder _json = new StringBuilder();
            _json.Append("[");
            Hashtable _table = new Hashtable();   //散列表，用于临时存储节点对象
            NodeTree _node = null;

            //将 datatable 转换到散列表中
            for (int i = 0, l = dt.Rows.Count; i < l; i++)
            {
                _node = new NodeTree();
                _node.ID = ConvertHelper.ToString(dt.Rows[i][attr.ID]);
                _node.Text = ConvertHelper.ToString(dt.Rows[i][attr.Text]);
                _node.ParentID = ConvertHelper.ToString(dt.Rows[i][attr.Pid]);
                _node.Children = new List<NodeTree>();
                _table.Add(_node.ID, _node);
            }

            IList<NodeTree> _roots = new List<NodeTree>();   //用于存储根节点对象
            foreach (object key in _table.Keys)
            {
                _node = (NodeTree)_table[key];
                if (string.IsNullOrEmpty(_node.ParentID))  //如果父节点为空，则表示是根节点
                {
                    _roots.Add(_node);
                }
                else
                {
                    //如果不是根节点，则找到该节点的父节点，并将该节点添加到父节点下
                    if (_table[_node.ParentID] != null)
                    {
                        ((NodeTree)_table[_node.ParentID]).AddChild(_node);
                    }
                }
            }

            //遍历根节点返回 json
            for (int k = 0, l = _roots.Count; k < l; k++)
            {
                _json.Append(_roots[k].ToString());
                if (k < l - 1)
                {
                    _json.Append(",");
                }
            }
            _json.Append("]");
            //JsonConvert.SerializeObject(_roots);

            return _json.ToString();
        }
        //转换 json menu
        public static string ToJsonMenu(DataTable dt, MenuAttr2 attr)
        {
            if (attr == null)
            {
                throw new ArgumentException("未指定节点对象属性");
            }
            if (dt == null || dt.Rows.Count == 0)
            {
                return "[]";
            }

            StringBuilder _json = new StringBuilder();
            _json.Append("[");
            Hashtable _table = new Hashtable();   //用于临时存储节点对象
            IList<MenuNode2> _nodes = new List<MenuNode2>();
            MenuNode2 _node = null;
            foreach (DataRow row in dt.Rows)
            {
                _node = new MenuNode2();
                _node.ID = ConvertHelper.ToString(row[attr.Id]);
                _node.Pid = ConvertHelper.ToString(row[attr.ParentID]);
                _node.Text = ConvertHelper.ToString(row[attr.FunctionName]);
                _node.Url = ConvertHelper.ToString(row[attr.Url]);
                _node.Img = ConvertHelper.ToString(row[attr.Img]);
                _node.isUsed = ConvertHelper.ToInt32(row[attr.IsUsed]);
                _node.Sort = ConvertHelper.ToDouble(row[attr.Sort]);
                _node.ilevel = ConvertHelper.ToInt32(row[attr.ilevel]);
                _node.model = ConvertHelper.ToString(row[attr.model]);
                /*_node.ID = ConvertHelper.ToString(row[attr.ID]);
                _node.Text = ConvertHelper.ToString(row[attr.Text]);
                _node.Pid = ConvertHelper.ToString(row[attr.Pid]);
                _node.Url = ConvertHelper.ToString(row[attr.Url]);
                _node.IconCls = ConvertHelper.ToString(row[attr.IconCls]);
                _node.Shortcuts = ConvertHelper.ToString(row[attr.Shortcuts]);
                _node.IsBillPage = ConvertHelper.ToBoolean(row[attr.IsBillPage]);
                _node.ProgramID = ConvertHelper.ToInt32(row[attr.ProgramID]);
                 */
                if (_table[_node.ID] == null)
                {
                    _table.Add(_node.ID, _node);
                    _nodes.Add(_node);
                }
            }
            //int i = 0, total = _table.Count;
            //foreach (object key in _table.Keys)
            //{
            //    _json.Append(((MenuNode)_table[key]).ToString());
            //    if (i++ < total - 1)
            //    {
            //        _json.Append(",");
            //    }
            //}
            for (int i = 0, l = _nodes.Count; i < l; i++)
            {
                _json.Append(_nodes[i].ToString());
                if (i < l - 1)
                {
                    _json.Append(",");
                }
            }
            _json.Append("]");
            return _json.ToString();
        }
        //转换通用的 json格式
        public static string ToCommonJson(DataTable dt)
        {
            StringBuilder _json = new StringBuilder();
            _json.Append("{items:[");
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    _json.Append("{");
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        _json.Append("\"" + ConvertHelper.ToString(dt.Columns[j].ColumnName) + "\":\"" + StrReplace(ConvertHelper.ToString(dt.Rows[i][j])) + "\"");
                        if (j < dt.Columns.Count - 1)
                        {
                            _json.Append(",");
                        }
                    }
                    _json.Append("}");
                    if (i < dt.Rows.Count - 1)
                    {
                        _json.Append(",");
                    }
                }
            }
            _json.Append("]}");
            return _json.ToString();
        }
        public static string StrReplace(string str)
        {
            str = str.Replace("\"", "\\\"");
            str = str.Replace("\n", "");
            str = str.Replace("\r", "");
            return str;
        }

        //树节点对象
        private class NodeTree
        {
            public string ID { get; set; }
            public string Text { get; set; }
            public string ParentID { get; set; }
            public List<NodeTree> Children { get; set; }
            public void AddChild(NodeTree node)
            {
                Children.Add(node);
            }
            public override string ToString()
            {
                StringBuilder _json = new StringBuilder();
                _json.Append("{id:\"").Append(ID).Append("\",");
                _json.Append("text:\"").Append(Text).Append("\"");
                if (Children.Count > 0)
                {
                    _json.Append(",children:[");
                    for (int i = 0, l = Children.Count; i < l; i++)
                    {
                        _json.Append(Children[i].ToString());
                        if (i < l - 1)
                        {
                            _json.Append(",");
                        }
                    }
                    _json.Append("]");
                }
                _json.Append("}");

                return _json.ToString();
            }
        }
        //菜单节点对象
        private class MenuNode
        {
            public string ID { get; set; }
            public string Text { get; set; }
            public string Pid { get; set; }
            public string Url { get; set; }
            public string IconCls { get; set; }
            public string Shortcuts { get; set; }
            public bool IsBillPage { get; set; }
            public int ProgramID { get; set; }
            public override string ToString()
            {
                StringBuilder _json = new StringBuilder();
                if (string.IsNullOrEmpty(Pid) || Pid == "0")
                {
                    _json.Append("{id:\"").Append(ID).Append("\",");
                    _json.Append("isbillpage:").Append(IsBillPage == true ? "true" : "false").Append(",");
                    _json.Append("programid:").Append(ProgramID).Append(",");
                    _json.Append("text:\"").Append(Text).Append("\"}");
                }
                else
                {
                    _json.Append("{id:\"").Append(ID).Append("\",");
                    _json.Append("text:\"").Append(Text).Append("\",");
                    _json.Append("pid:\"").Append(Pid).Append("\",");
                    _json.Append("isbillpage:").Append(IsBillPage == true ? "true" : "false").Append(",");
                    _json.Append("programid:").Append(ProgramID).Append(",");
                    _json.Append("url:\"").Append(Url).Append("\",");
                    _json.Append("shortcuts:\"").Append(Shortcuts).Append("\",");
                    _json.Append("iconCls:\"").Append(IconCls).Append("\"}");
                }
                return _json.ToString();
            }
        }
        private class MenuNode2
        {
            public string ID { get; set; }
            public string Text { get; set; }
            public string Pid { get; set; }
            public string Url { get; set; }
            public string Img { get; set; }
            public int isUsed { get; set; }
            public double Sort { get; set; }
            public int ilevel { get; set; }
            public string model { get; set; }
            public override string ToString()
            {
                StringBuilder _json = new StringBuilder();
                if (string.IsNullOrEmpty(Pid))
                {
                    Pid = "0";
                }
                _json.Append("{ID:\"").Append(ID).Append("\",");
                _json.Append("functionName:\"").Append(Text).Append("\",");
                _json.Append("parentID:\"").Append(Pid).Append("\",");
                _json.Append("url:\"").Append(Url).Append("\",");
                _json.Append("isUsed:").Append(isUsed).Append(",");
                _json.Append("sort:").Append(Sort).Append(",");
                _json.Append("ilevel:").Append(ilevel).Append(",");
                _json.Append("model:\"").Append(model).Append("\",");
                _json.Append("img:\"").Append(Img).Append("\"}");
                return _json.ToString();
            }
        }
    }

    public class TreeAttr
    {
        public TreeAttr(string id, string text, string pid)
        {
            this.ID = id;
            this.Text = text;
            this.Pid = pid;
        }
        public string ID { get; set; }
        public string Text { get; set; }
        public string Pid { get; set; }
    }
    public class MenuAttr
    {
        public MenuAttr(string id, string text, string pid, string url, string iconcls, string shortcuts, string isBillPage, string programid)
        {
            this.ID = id;
            this.Text = text;
            this.Pid = pid;
            this.Url = url;
            this.IconCls = iconcls;
            this.Shortcuts = shortcuts;
            this.IsBillPage = isBillPage;
            this.ProgramID = programid;
        }
        public string ID { get; set; }
        public string Text { get; set; }
        public string Pid { get; set; }
        public string Url { get; set; }
        public string IconCls { get; set; }
        public string Shortcuts { get; set; }
        public string IsBillPage { get; set; }
        public string ProgramID { get; set; }
    }

    public class MenuAttr2
    {
        private string _id;

        public string Id
        {
            get { return _id; }
            set { _id = value; }
        }
        private string _parentID;

        public string ParentID
        {
            get { return _parentID; }
            set { _parentID = value; }
        }
        private string _functionName;

        public string FunctionName
        {
            get { return _functionName; }
            set { _functionName = value; }
        }
        private string _url;

        public string Url
        {
            get { return _url; }
            set { _url = value; }
        }
        private string _img;

        public string Img
        {
            get { return _img; }
            set { _img = value; }
        }
        private string _isUsed;

        public string IsUsed
        {
            get { return _isUsed; }
            set { _isUsed = value; }
        }
        private string _sort;
        public string Sort
        {
            get { return _sort; }
            set { _sort = value; }
        }

        private string _ilevel;
        public string ilevel
        {
            get { return _ilevel; }
            set { _ilevel = value; }
        }

        private string _model;
        public string model
        {
            get { return _model; }
            set { _model = value; }
        }
    }
}